package com.example.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class JarvisAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        _isRunning.value = true
        instance = this

        val info = serviceInfo ?: AccessibilityServiceInfo()
        info.eventTypes = AccessibilityEvent.TYPES_ALL_MASK
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
        info.flags = AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS or
                AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
        serviceInfo = info
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Can be used to track active foreground apps or user UI interactions
    }

    override fun onInterrupt() {
        // Interrupted by system
    }

    override fun onDestroy() {
        super.onDestroy()
        _isRunning.value = false
        if (instance == this) {
            instance = null
        }
    }

    companion object {
        private val _isRunning = MutableStateFlow(false)
        val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

        var instance: JarvisAccessibilityService? = null
            private set

        fun isAccessibilityEnabled(context: Context): Boolean {
            val expectedServiceName = "${context.packageName}/${JarvisAccessibilityService::class.java.name}"
            val enabledServices = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            return enabledServices.contains(expectedServiceName) || _isRunning.value
        }

        fun openAccessibilitySettings(context: Context) {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }

        fun performHome(): Boolean =
            instance?.performGlobalAction(GLOBAL_ACTION_HOME) ?: false

        fun performBack(): Boolean =
            instance?.performGlobalAction(GLOBAL_ACTION_BACK) ?: false

        fun performRecents(): Boolean =
            instance?.performGlobalAction(GLOBAL_ACTION_RECENTS) ?: false

        fun performNotifications(): Boolean =
            instance?.performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS) ?: false

        fun performQuickSettings(): Boolean =
            instance?.performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS) ?: false

        fun performLockScreen(): Boolean {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                instance?.performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN) ?: false
            } else {
                false
            }
        }

        fun performScreenshot(): Boolean {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                instance?.performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT) ?: false
            } else {
                false
            }
        }

        fun clickText(text: String): Boolean {
            val root = instance?.rootInActiveWindow ?: return false
            val clean = text.lowercase().trim()
            if (clean.isBlank()) return false

            // 1. Direct text search
            val nodes = root.findAccessibilityNodeInfosByText(text)
            if (!nodes.isNullOrEmpty()) {
                for (node in nodes) {
                    if (node.isClickable && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        return true
                    }
                    var parent = node.parent
                    while (parent != null) {
                        if (parent.isClickable && parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                            return true
                        }
                        parent = parent.parent
                    }
                }
            }

            // 2. Recursive fuzzy traversal over text and contentDescription
            fun searchAndClick(node: AccessibilityNodeInfo?): Boolean {
                if (node == null) return false
                val nText = node.text?.toString()?.lowercase() ?: ""
                val nDesc = node.contentDescription?.toString()?.lowercase() ?: ""
                if (nText.contains(clean) || nDesc.contains(clean)) {
                    if (node.isClickable && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        return true
                    }
                    var p = node.parent
                    while (p != null) {
                        if (p.isClickable && p.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                            return true
                        }
                        p = p.parent
                    }
                }
                for (i in 0 until node.childCount) {
                    if (searchAndClick(node.getChild(i))) return true
                }
                return false
            }

            return searchAndClick(root)
        }

        fun inputText(text: String): Boolean {
            val root = instance?.rootInActiveWindow ?: return false
            val focusNode = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            val bundle = android.os.Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            }
            if (focusNode != null && focusNode.isEditable) {
                return focusNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, bundle)
            }

            fun findEditableAndSet(node: AccessibilityNodeInfo?): Boolean {
                if (node == null) return false
                if (node.isEditable) {
                    return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, bundle)
                }
                for (i in 0 until node.childCount) {
                    if (findEditableAndSet(node.getChild(i))) return true
                }
                return false
            }

            return findEditableAndSet(root)
        }

        fun clickFirstResult(): Boolean {
            val root = instance?.rootInActiveWindow ?: return false
            fun findFirstClickable(node: AccessibilityNodeInfo?): Boolean {
                if (node == null) return false
                for (i in 0 until node.childCount) {
                    val child = node.getChild(i)
                    if (child != null && child.isClickable && child.className?.contains("Button") != true) {
                        return child.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    }
                    if (findFirstClickable(child)) return true
                }
                return false
            }
            return findFirstClickable(root)
        }
    }
}
