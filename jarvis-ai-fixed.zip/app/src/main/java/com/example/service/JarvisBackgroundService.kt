package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.util.DeviceController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.abs

class JarvisBackgroundService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private val mainHandler = Handler(Looper.getMainLooper())

    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    private var isAudioThreadRunning = false
    private var lastWakeTriggerTime = 0L

    override fun onCreate() {
        super.onCreate()
        try {
            createNotificationChannel()
            val notification = buildNotification(
                "JARVIS Background Listening Active",
                "Wake Word: 'Hey Jarvis' listening..."
            )
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            _isRunning.value = true
            initTts()
            initSpeechRecognizer()
            startAudioActivityMonitoring()
        } catch (e: Exception) {
            _isRunning.value = false
            stopSelf()
            throw e
        }
    }

    private fun initTts() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isTtsReady = true
                tts?.let { engine ->
                    val hindi = Locale("hi", "IN")
                    val result = engine.setLanguage(hindi)
                    if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        engine.language = Locale.getDefault()
                    }
                    engine.setPitch(0.92f)
                    engine.setSpeechRate(1.0f)
                }
            }
        }
    }

    fun speakDirect(text: String) {
        mainHandler.post {
            try {
                val params = Bundle().apply {
                    putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "JARVIS_BG_WAKE")
                }
                tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "JARVIS_BG_WAKE")
            } catch (e: Exception) {
                // Ignore
            }
        }
    }

    private fun initSpeechRecognizer() {
        mainHandler.post {
            if (SpeechRecognizer.isRecognitionAvailable(this)) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                    setRecognitionListener(object : RecognitionListener {
                        override fun onReadyForSpeech(params: Bundle?) {}
                        override fun onBeginningOfSpeech() {}
                        override fun onRmsChanged(rmsdB: Float) {}
                        override fun onBufferReceived(buffer: ByteArray?) {}
                        override fun onEndOfSpeech() {}
                        override fun onError(error: Int) {
                            scheduleNextRecognition()
                        }
                        override fun onResults(results: Bundle?) {
                            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            val text = matches?.firstOrNull()?.trim() ?: ""
                            if (text.isNotBlank()) {
                                handleRecognizedText(text)
                            }
                            scheduleNextRecognition()
                        }
                        override fun onPartialResults(partialResults: Bundle?) {
                            val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            val text = matches?.firstOrNull()?.trim() ?: ""
                            if (text.isNotBlank()) {
                                handleRecognizedText(text)
                            }
                        }
                        override fun onEvent(eventType: Int, params: Bundle?) {}
                    })
                }
                startRecognitionCycle()
            }
        }
    }

    private fun startRecognitionCycle() {
        mainHandler.post {
            try {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                }
                speechRecognizer?.startListening(intent)
            } catch (e: Exception) {
                scheduleNextRecognition()
            }
        }
    }

    private fun scheduleNextRecognition() {
        serviceScope.launch {
            delay(1500)
            if (_isRunning.value) {
                startRecognitionCycle()
            }
        }
    }

    // Continuous audio amplitude level monitoring as resilient acoustic wake trigger
    private fun startAudioActivityMonitoring() {
        isAudioThreadRunning = true
        serviceScope.launch(Dispatchers.IO) {
            val sampleRate = 16000
            val channelConfig = AudioFormat.CHANNEL_IN_MONO
            val audioFormat = AudioFormat.ENCODING_PCM_16BIT
            val bufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)

            if (bufferSize <= 0) return@launch

            var audioRecord: AudioRecord? = null
            try {
                audioRecord = AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    sampleRate,
                    channelConfig,
                    audioFormat,
                    bufferSize
                )

                if (audioRecord.state == AudioRecord.STATE_INITIALIZED) {
                    audioRecord.startRecording()
                    val buffer = ShortArray(bufferSize / 2)

                    while (isActive && isAudioThreadRunning && _isRunning.value) {
                        val read = audioRecord.read(buffer, 0, buffer.size)
                        if (read > 0) {
                            var maxAmp = 0
                            for (i in 0 until read) {
                                val absVal = abs(buffer[i].toInt())
                                if (absVal > maxAmp) maxAmp = absVal
                            }

                            // Strong voice threshold detected while in background
                            val now = System.currentTimeMillis()
                            if (maxAmp > 14000 && (now - lastWakeTriggerTime) > 6000) {
                                // High voice burst detected, restart speech recognizer or trigger wake
                                mainHandler.post {
                                    startRecognitionCycle()
                                }
                            }
                        }
                        delay(100)
                    }
                }
            } catch (e: Exception) {
                // AudioRecord failed (permission or busy), speech recognizer remains fallback
            } finally {
                try {
                    audioRecord?.stop()
                    audioRecord?.release()
                } catch (e: Exception) {
                    // Ignore
                }
            }
        }
    }

    private fun handleRecognizedText(text: String) {
        val clean = text.lowercase().trim()
        val isWakeMatch = isWakeWordMatch(clean)

        if (isWakeMatch) {
            triggerWakeResponse()
        }
    }

    fun triggerWakeResponse() {
        val now = System.currentTimeMillis()
        if (now - lastWakeTriggerTime < 2500) return // Debounce
        lastWakeTriggerTime = now

        DeviceController.vibrate(this, 90)

        // The exact phrase requested by the user: "Haan sir, main active hoon! Boliye, kya kaam hai?"
        val wakeReply = "Haan sir, main active hoon! Boliye, kya kaam hai?"
        speakDirect(wakeReply)

        // Bring Jarvis into active foreground
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra("EXTRA_WAKE_TRIGGER", true)
        }
        startActivity(launchIntent)
    }

    private fun isWakeWordMatch(query: String): Boolean {
        val wakeList = listOf(
            "jarvis",
            "jarvish",
            "jarwis",
            "char mis",
            "charmis",
            "hai jarvis",
            "hey jarvis",
            "hi jarvis",
            "hello jarvis",
            "zarvis",
            "javis",
            "sarvis",
            "service",
            "oy jarvis",
            "oye jarvis",
            "wake up",
            "sun rahe ho",
            "active ho"
        )
        return wakeList.any { query.contains(it) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TRIGGER_WAKE -> {
                triggerWakeResponse()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        _isRunning.value = false
        isAudioThreadRunning = false
        serviceScope.cancel()

        mainHandler.post {
            try {
                speechRecognizer?.destroy()
                speechRecognizer = null
            } catch (e: Exception) {
                // Ignore
            }
            try {
                tts?.shutdown()
                tts = null
            } catch (e: Exception) {
                // Ignore
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "JARVIS Background Assistant",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Monitors wake-word and background autonomous commands"
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(title: String, content: String): Notification {
        val launchIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val wakeIntent = Intent(this, JarvisBackgroundService::class.java).apply {
            action = ACTION_TRIGGER_WAKE
        }
        val wakePendingIntent = PendingIntent.getService(
            this,
            1,
            wakeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, JarvisBackgroundService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            2,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(content)
            .setContentIntent(pendingIntent)
            .addAction(R.drawable.ic_launcher_foreground, "🎤 HEY JARVIS", wakePendingIntent)
            .addAction(R.drawable.ic_launcher_foreground, "STOP", stopPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    companion object {
        const val CHANNEL_ID = "jarvis_bg_channel"
        const val NOTIFICATION_ID = 1007
        const val ACTION_STOP = "com.example.service.STOP_BG_SERVICE"
        const val ACTION_TRIGGER_WAKE = "com.example.service.TRIGGER_WAKE"

        private val _isRunning = MutableStateFlow(false)
        val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

        fun start(context: Context) {
            val intent = Intent(context, JarvisBackgroundService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, JarvisBackgroundService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }

        fun triggerWake(context: Context) {
            val intent = Intent(context, JarvisBackgroundService::class.java).apply {
                action = ACTION_TRIGGER_WAKE
            }
            context.startService(intent)
        }
    }
}
