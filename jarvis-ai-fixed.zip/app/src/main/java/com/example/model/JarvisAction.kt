package com.example.model

sealed interface JarvisAction {
    data class LaunchApp(val appName: String, val packageName: String) : JarvisAction
    data class ToggleFlashlight(val turnOn: Boolean) : JarvisAction
    data class ChangeVolume(val increase: Boolean) : JarvisAction
    data class ExecuteGesture(val gestureType: GestureType) : JarvisAction
    data class OpenSetting(val settingName: String, val actionIntent: String) : JarvisAction
    data object QueryBattery : JarvisAction
    data class SearchWeb(val query: String) : JarvisAction
    data class OpenUrl(val url: String) : JarvisAction
    data class DialNumber(val number: String) : JarvisAction
    data class ControlStateToggle(val enable: Boolean) : JarvisAction
    data class SaveMemory(val content: String, val category: String = "GENERAL") : JarvisAction
    data class Conversational(val reply: String) : JarvisAction
}

enum class GestureType {
    HOME,
    BACK,
    RECENTS,
    NOTIFICATIONS,
    QUICK_SETTINGS,
    LOCK_SCREEN,
    SCREENSHOT
}
