package com.example.model

import java.util.UUID

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val isJarvis: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val actionSummary: String? = null,
    val isVoice: Boolean = false
)
