package com.example.viewmodel

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.SystemClock
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.memory.JarvisDatabase
import com.example.data.memory.MemoryEntity
import com.example.model.ChatMessage
import com.example.model.GestureType
import com.example.model.InstalledAppInfo
import com.example.service.JarvisAccessibilityService
import com.example.service.JarvisBackgroundService
import com.example.util.AppMatcher
import com.example.util.DeviceController
import com.example.util.GeminiAIService
import com.example.util.GeminiExecutionResult
import com.example.util.JarvisExecutionStep
import com.example.util.LocalCommandRouter
import com.example.util.VoiceManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class JarvisTab {
    CORE_HUD,
    VOICE_CHAT,
    PHONE_CONTROL,
    MEMORY_VAULT,
    SYSTEM_LOGS
}

class JarvisViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext
    private val memoryDao = JarvisDatabase.getDatabase(application).memoryDao()

    val memories: StateFlow<List<MemoryEntity>> = memoryDao.getAllMemoriesFlow()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    private val _phoneControlEnabled = MutableStateFlow(false)
    val phoneControlEnabled: StateFlow<Boolean> = _phoneControlEnabled.asStateFlow()

    private val _isAccessibilityGranted = MutableStateFlow(false)
    val isAccessibilityGranted: StateFlow<Boolean> = _isAccessibilityGranted.asStateFlow()

    private val _isBackgroundListeningEnabled = MutableStateFlow(false)
    val isBackgroundListeningEnabled: StateFlow<Boolean> = _isBackgroundListeningEnabled.asStateFlow()

    private val _backgroundListeningError = MutableStateFlow<String?>(null)
    val backgroundListeningError: StateFlow<String?> = _backgroundListeningError.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _systemLogs = MutableStateFlow<List<String>>(emptyList())
    val systemLogs: StateFlow<List<String>> = _systemLogs.asStateFlow()

    private val _batteryLevel = MutableStateFlow(85)
    val batteryLevel: StateFlow<Int> = _batteryLevel.asStateFlow()

    private val _isCharging = MutableStateFlow(false)
    val isCharging: StateFlow<Boolean> = _isCharging.asStateFlow()

    private val _isFlashlightOn = MutableStateFlow(false)
    val isFlashlightOn: StateFlow<Boolean> = _isFlashlightOn.asStateFlow()

    private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppInfo>> = _installedApps.asStateFlow()

    private val _activeTab = MutableStateFlow(JarvisTab.CORE_HUD)
    val activeTab: StateFlow<JarvisTab> = _activeTab.asStateFlow()

    private val _voiceAutoSpeakEnabled = MutableStateFlow(true)
    val voiceAutoSpeakEnabled: StateFlow<Boolean> = _voiceAutoSpeakEnabled.asStateFlow()

    private var voiceManager: VoiceManager? = null

    val isListening: StateFlow<Boolean>
        get() = voiceManager?.isListening ?: MutableStateFlow(false).asStateFlow()

    val isSpeaking: StateFlow<Boolean>
        get() = voiceManager?.isSpeaking ?: MutableStateFlow(false).asStateFlow()

    val rmsDb: StateFlow<Float>
        get() = voiceManager?.rmsDb ?: MutableStateFlow(0f).asStateFlow()

    init {
        initVoice()
        refreshSystemStatus()
        loadInstalledApps()

        addSystemLog("SYSTEM: J.A.R.V.I.S. Neural Core Online")
        addSystemLog("MEMORY: Permanent Room Database Initialized")

        _messages.value = listOf(
            ChatMessage(
                text = "Namaste Sir! Main JARVIS hoon. Jo bhi kaam bolenge, Gemini AI se execute karke asli phone actions karunga!",
                isJarvis = true
            )
        )

        viewModelScope.launch {
            JarvisAccessibilityService.isRunning.collect { running ->
                _isAccessibilityGranted.value = running || JarvisAccessibilityService.isAccessibilityEnabled(context)
                if (running) {
                    addSystemLog("ACCESSIBILITY: Jarvis Automation Bridge Connected")
                }
            }
        }

        // Toggle state strictly mirrors actual service running state
        viewModelScope.launch {
            JarvisBackgroundService.isRunning.collect { running ->
                _isBackgroundListeningEnabled.value = running
                if (running) {
                    _backgroundListeningError.value = null
                }
            }
        }
    }

    private fun initVoice() {
        voiceManager = VoiceManager(context) { recognizedText ->
            processUserCommand(recognizedText, isVoice = true)
        }
        voiceManager?.onSpeechErrorCallback = { errorMsg ->
            addSystemLog("VOICE_EVENT: $errorMsg")
        }
    }

    fun selectTab(tab: JarvisTab) {
        _activeTab.value = tab
    }

    fun refreshSystemStatus() {
        val (level, charging) = DeviceController.getBatteryInfo(context)
        _batteryLevel.value = level
        _isCharging.value = charging
        _isAccessibilityGranted.value = JarvisAccessibilityService.isAccessibilityEnabled(context)
        _isFlashlightOn.value = DeviceController.isFlashlightActive()
        _isBackgroundListeningEnabled.value = JarvisBackgroundService.isRunning.value
    }

    fun loadInstalledApps() {
        viewModelScope.launch(Dispatchers.IO) {
            val apps = DeviceController.getInstalledApps(context)
            _installedApps.value = apps
            addSystemLog("PACKAGE_SCAN: Found ${apps.size} installed applications ready for direct execution")
        }
    }

    fun setPhoneControlEnabled(enabled: Boolean) {
        _phoneControlEnabled.value = enabled
        DeviceController.vibrate(context, 70)
        if (enabled) {
            addSystemLog("ALERT: Autonomous Phone Control Mode ENGAGED")
            speak("Autonomous phone control activate kar diya hai, sir. Ab jo bhi command denge main turant execute karunga.")
            _messages.value = _messages.value + ChatMessage(
                text = "Autonomous Phone Control mode activate ho gaya hai! JARVIS ke paas pure phone ka control hai.",
                isJarvis = true,
                actionSummary = "Phone Control Master Switch: ACTIVE"
            )
        } else {
            addSystemLog("STATUS: Autonomous Phone Control Mode Disengaged")
            speak("Phone control band kar diya gaya hai, sir.")
            _messages.value = _messages.value + ChatMessage(
                text = "Phone control mode deactivate ho gaya hai. Manual control restore kar diya gaya hai.",
                isJarvis = true,
                actionSummary = "Phone Control Master Switch: INACTIVE"
            )
        }
    }

    // Toggle Background Listening with runtime permissions and real service startup
    fun toggleBackgroundListening(enabled: Boolean, onNeedsPermission: () -> Unit) {
        DeviceController.vibrate(context, 50)
        if (enabled) {
            val hasAudio = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            val hasNotif = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            } else true

            if (!hasAudio || !hasNotif) {
                _backgroundListeningError.value = "Microphone aur Notification permissions zaroori hain. Allow karein."
                addSystemLog("PERMISSION_REQUEST: Prompting user for RECORD_AUDIO and POST_NOTIFICATIONS")
                onNeedsPermission()
                return
            }

            startBackgroundServiceInternal()
        } else {
            JarvisBackgroundService.stop(context)
            _backgroundListeningError.value = null
            addSystemLog("SERVICE: Background Wake-Word Listener STOPPED")
            speak("Background listening band kar di gayi hai, sir.")
            _messages.value = _messages.value + ChatMessage(
                text = "Background listening deactivated.",
                isJarvis = true,
                actionSummary = "Background Wake-Word: OFF"
            )
        }
    }

    fun onBackgroundPermissionResult(audioGranted: Boolean, notifGranted: Boolean) {
        if (audioGranted && notifGranted) {
            _backgroundListeningError.value = null
            startBackgroundServiceInternal()
        } else {
            val missing = mutableListOf<String>()
            if (!audioGranted) missing.add("Microphone")
            if (!notifGranted) missing.add("Notification")
            val msg = "Permission Denied: ${missing.joinToString(" aur ")} permission allow karein background listening ke liye."
            _backgroundListeningError.value = msg
            addSystemLog("PERMISSION_FAIL: $msg")
            speak("Sir, background listening ke liye microphone aur notification permissions zaroori hain.")
        }
    }

    fun startBackgroundServiceInternal() {
        try {
            JarvisBackgroundService.start(context)
            _backgroundListeningError.value = null
            addSystemLog("SERVICE: Background Wake-Word ('Hey Jarvis') Listener STARTED")
            speak("Background listening activate ho gayi hai, sir! Chahe app band ho ya screen lock ho, 'Hey Jarvis' bolte hi main active ho jaunga.")
            _messages.value = _messages.value + ChatMessage(
                text = "Background listening active: Jarvis background mein 'Hey Jarvis' wake-word monitor kar raha hai.",
                isJarvis = true,
                actionSummary = "Background Wake-Word: ON"
            )
        } catch (e: Exception) {
            val errorMsg = e.localizedMessage ?: e.message ?: "Service start error"
            _backgroundListeningError.value = "Service start fail: $errorMsg"
            addSystemLog("SERVICE_ERROR: Failed to start background listener - $errorMsg")
        }
    }

    fun clearBackgroundError() {
        _backgroundListeningError.value = null
    }

    fun onReactorCoreClicked() {
        DeviceController.vibrate(context, 60)
        if (isListening.value) {
            stopListening()
        } else {
            val prompt = "Haan sir, main active hoon! Boliye, kya kaam hai?"
            speak(prompt)
            _messages.value = _messages.value + ChatMessage(
                text = prompt,
                isJarvis = true
            )
            startListening()
        }
    }

    fun triggerWakeWordTest() {
        DeviceController.vibrate(context, 70)
        val reply = "Haan sir, main active hoon! Boliye, kya kaam hai?"
        speak(reply)
        _messages.value = _messages.value + ChatMessage(
            text = reply,
            isJarvis = true,
            actionSummary = "Wake Word: 'Hey Jarvis' Verified"
        )
        addSystemLog("WAKE_TEST: 'Hey Jarvis' triggered -> Responded in Hindi")
    }

    fun toggleVoiceAutoSpeak() {
        _voiceAutoSpeakEnabled.value = !_voiceAutoSpeakEnabled.value
    }

    fun startListening() {
        voiceManager?.startListening()
    }

    fun stopListening() {
        voiceManager?.stopListening()
    }

    fun speak(text: String) {
        if (_voiceAutoSpeakEnabled.value) {
            voiceManager?.speak(text)
        }
    }

    fun stopSpeaking() {
        voiceManager?.stopSpeaking()
    }

    fun saveMemory(content: String, category: String = "GENERAL") {
        viewModelScope.launch(Dispatchers.IO) {
            val memory = MemoryEntity(content = content, category = category)
            memoryDao.insertMemory(memory)
            addSystemLog("MEMORY_STORE: Saved -> '$content'")
        }
    }

    fun deleteMemory(memory: MemoryEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            memoryDao.deleteMemory(memory)
            addSystemLog("MEMORY_DELETE: Removed memory ID ${memory.id}")
        }
    }

    fun clearAllMemories() {
        viewModelScope.launch(Dispatchers.IO) {
            memoryDao.clearAll()
            addSystemLog("MEMORY_WIPE: All permanent memories cleared")
        }
    }

    fun saveCustomGeminiKey(key: String) {
        context.getSharedPreferences("jarvis_prefs", Context.MODE_PRIVATE)
            .edit()
            .putString("custom_gemini_api_key", key.trim())
            .apply()
        addSystemLog("API_KEY: Gemini API Key updated")
    }

    fun toggleFlashlight() {
        val success = DeviceController.toggleFlashlight(context)
        if (success) {
            val state = DeviceController.isFlashlightActive()
            _isFlashlightOn.value = state
            val msg = if (state) "Torch jala di hai, sir" else "Torch band kar di hai, sir"
            addSystemLog("HARDWARE: $msg")
            speak(msg)
        }
    }

    fun launchAppByPackage(packageName: String, label: String) {
        addSystemLog("APP_EXEC: Launching $label ($packageName)")
        val success = DeviceController.launchApp(context, packageName)
        if (success) {
            speak("Ji sir, $label open kar diya hai.")
            _messages.value = _messages.value + ChatMessage(
                text = "Successfully opened $label application.",
                isJarvis = true,
                actionSummary = "Launched $label"
            )
        } else {
            addSystemLog("APP_EXEC_ERROR: Unable to launch $packageName")
        }
    }

    fun executeGesture(gesture: GestureType) {
        val actionName = gesture.name
        val success = when (gesture) {
            GestureType.HOME -> JarvisAccessibilityService.performHome()
            GestureType.BACK -> JarvisAccessibilityService.performBack()
            GestureType.RECENTS -> JarvisAccessibilityService.performRecents()
            GestureType.NOTIFICATIONS -> JarvisAccessibilityService.performNotifications()
            GestureType.QUICK_SETTINGS -> JarvisAccessibilityService.performQuickSettings()
            GestureType.LOCK_SCREEN -> JarvisAccessibilityService.performLockScreen()
            GestureType.SCREENSHOT -> JarvisAccessibilityService.performScreenshot()
        }

        if (success) {
            addSystemLog("GESTURE_SUCCESS: Executed $actionName")
            DeviceController.vibrate(context, 40)
        } else {
            addSystemLog("GESTURE_PENDING: Accessibility service required for $actionName. Tap 'Setup Access'.")
            if (!_isAccessibilityGranted.value) {
                JarvisAccessibilityService.openAccessibilitySettings(context)
            }
        }
    }

    fun openAccessibilitySettings() {
        JarvisAccessibilityService.openAccessibilitySettings(context)
    }

    private data class StepOutcome(val ok: Boolean, val detail: String = "")

    // Command ka naya rasta:
    // 1) pehle tez local niyam (torch, volume, app kholna, YouTube search, ...) - Gemini ki zaroorat nahi
    // 2) koi niyam match na ho tabhi Gemini ko bulao
    // 3) steps ek-ek karke chalao aur har step ka sachcha result LOGS me likho
    fun processUserCommand(input: String, isVoice: Boolean = false) {
        if (input.isBlank()) return

        // 1. Post user message in chat
        _messages.value = _messages.value + ChatMessage(
            text = input,
            isJarvis = false,
            isVoice = isVoice
        )

        viewModelScope.launch {
            val lower = input.lowercase().trim()

            // Memory Recall check
            if (lower.contains("kya yaad hai") || lower.contains("meri memory") ||
                lower.contains("mera naam kya hai") || lower.contains("purani baatein") ||
                lower.contains("kuch yaad hai")) {
                val currentMemories = memoryDao.getAllMemories()
                val reply = if (currentMemories.isNotEmpty()) {
                    val facts = currentMemories.take(5).joinToString(", ") { it.content }
                    "Sir, mujhe aapki ye baatein hamesha ke liye yaad hain: $facts"
                } else {
                    "Sir, abhi meri permanent memory mein koi purani baat saved nahi hai. Aap 'yaad rakhna ki [baat]' bolkar kuch bhi hamesha ke liye save karwa sakte hain!"
                }
                speak(reply)
                _messages.value = _messages.value + ChatMessage(
                    text = reply,
                    isJarvis = true,
                    actionSummary = "Memory Recall: Retrieved ${currentMemories.size} facts",
                    isVoice = isVoice
                )
                return@launch
            }

            val startedAt = SystemClock.elapsedRealtime()

            // Installed apps ki list (cache se, tez)
            var apps = _installedApps.value
            if (apps.isEmpty()) {
                apps = withContext(Dispatchers.IO) { DeviceController.getInstalledAppsCached(context) }
            }

            // 1) Tez local niyam
            val local = withContext(Dispatchers.Default) {
                LocalCommandRouter.route(input, context, apps)
            }

            val result: GeminiExecutionResult
            if (local != null) {
                result = local
                addSystemLog("LOCAL_RULE: matched in ${SystemClock.elapsedRealtime() - startedAt}ms (Gemini skipped) -> \"$input\"")
            } else {
                // 2) Koi niyam match nahi hua -> Gemini
                addSystemLog("GEMINI_ROUTER: no local rule matched, asking Gemini -> \"$input\"")
                val appLabels = apps.sortedBy { it.isSystem }.map { it.label }
                val currentMemories = memoryDao.getAllMemories()
                result = GeminiAIService.executeComplexCommand(
                    prompt = input,
                    context = context,
                    installedApps = appLabels,
                    memories = currentMemories
                )
                addSystemLog("GEMINI_DONE: ${SystemClock.elapsedRealtime() - startedAt}ms, ${result.steps.size} step(s)")
                result.note?.let { addSystemLog("GEMINI_WARNING: $it") }
            }

            // Save memory if a fact was flagged (REMEMBER_FACT step khud save karta hai, double save nahi)
            result.newMemoryToSave?.let { fact ->
                if (result.steps.none { it.actionType == "REMEMBER_FACT" }) saveMemory(fact)
            }

            // Post Jarvis Hinglish reply and speak
            val stepCount = result.steps.size
            val sourceLabel = when (result.source) {
                "LOCAL" -> "Local"
                "GEMINI" -> "Gemini"
                else -> "Fallback"
            }
            _messages.value = _messages.value + ChatMessage(
                text = result.hinglishReply,
                isJarvis = true,
                actionSummary = if (stepCount > 0) "Executing $stepCount step plan ($sourceLabel)" else "Conversation ($sourceLabel)",
                isVoice = isVoice
            )
            speak(result.hinglishReply)

            // 3) Steps ek-ek karke chalao
            if (stepCount > 0) {
                addSystemLog("PLAN_START: $stepCount-step plan ($sourceLabel) for: \"$input\"")
                var okCount = 0

                for (index in result.steps.indices) {
                    val step = result.steps[index]
                    val stepNum = index + 1
                    val targetInfo = if (step.target.isBlank()) "" else " -> ${step.target}"

                    addSystemLog("STEP $stepNum/$stepCount: Starting -> ${step.description} [${step.actionType}$targetInfo]")

                    val outcome = executeSingleStep(step)

                    if (outcome.ok) {
                        okCount++
                        addSystemLog("STEP $stepNum/$stepCount SUCCESS: ${outcome.detail.ifBlank { step.description }}")
                    } else {
                        addSystemLog("STEP $stepNum/$stepCount FAILED: ${outcome.detail}")
                        _messages.value = _messages.value + ChatMessage(
                            text = outcome.detail,
                            isJarvis = true,
                            actionSummary = "Step $stepNum/$stepCount failed",
                            isVoice = isVoice
                        )
                        speak(outcome.detail)
                    }

                    if (index < stepCount - 1) {
                        val pause = pauseAfter(step, result.steps[index + 1])
                        addSystemLog("STEP_PAUSE: Waiting ${pause}ms before next step...")
                        delay(pause)
                    }
                }

                if (okCount == stepCount) {
                    addSystemLog("PLAN_COMPLETE: All $stepCount steps executed successfully.")
                } else {
                    addSystemLog("PLAN_INCOMPLETE: $okCount/$stepCount steps successful.")
                }
            }
        }
    }

    // Screen badalne wale steps ko wait chahiye; torch/volume jaise turant hone wale steps ko nahi.
    private fun pauseAfter(step: JarvisExecutionStep, next: JarvisExecutionStep): Long = when (step.actionType) {
        "LAUNCH_APP" -> if (next.actionType == "SEARCH_YOUTUBE") 1200L else 2000L
        "SEARCH_YOUTUBE" -> 2500L
        "OPEN_SETTING", "CLICK_TEXT", "INPUT_TEXT", "SEARCH_WEB", "DIAL_NUMBER" -> 2000L
        else -> 300L
    }

    private fun gestureOutcome(name: String, ok: Boolean): StepOutcome =
        if (ok) StepOutcome(true, "$name ho gaya")
        else StepOutcome(false, "Sir, $name nahi ho paya. Accessibility service chalu karein ('Setup Access').")

    private fun launchStep(step: JarvisExecutionStep): StepOutcome {
        var pkg = step.packageName
        var label = step.target

        if (pkg.isBlank()) {
            var apps = _installedApps.value
            if (apps.isEmpty()) apps = DeviceController.getInstalledAppsCached(context)

            val cleaned = AppMatcher.cleanAppName(step.target).ifBlank { step.target.trim() }
            val match = AppMatcher.findBest(step.target, apps)
            if (match == null) {
                val suggestions = AppMatcher.suggest(step.target, apps, 3).joinToString(", ") { it.label }
                val extra = if (suggestions.isNotBlank()) " Milte-julte apps: $suggestions." else ""
                return StepOutcome(false, "Sir, '$cleaned' naam ka app mujhe phone mein nahi mila.$extra")
            }
            pkg = match.app.packageName
            label = match.app.label
            addSystemLog("APP_MATCH: '${step.target}' -> '$cleaned' -> $label ($pkg) score ${"%.2f".format(match.score)}")
        }

        return if (DeviceController.launchApp(context, pkg)) {
            StepOutcome(true, "$label open kar diya ($pkg)")
        } else {
            StepOutcome(false, "Sir, $label open nahi ho paya ($pkg).")
        }
    }

    // Direct execution of atomic steps using the exact same code that quick buttons run!
    private fun executeSingleStep(step: JarvisExecutionStep): StepOutcome {
        return when (step.actionType) {
            "LAUNCH_APP" -> launchStep(step)
            "SEARCH_YOUTUBE" -> {
                val ok = DeviceController.searchYouTube(context, step.target)
                StepOutcome(ok, if (ok) "YouTube search: ${step.target}" else "Sir, YouTube search nahi ho paya.")
            }
            "CLICK_TEXT" -> {
                val clicked = JarvisAccessibilityService.clickText(step.target) ||
                    JarvisAccessibilityService.clickFirstResult()
                StepOutcome(clicked, if (clicked) "Tap ho gaya: ${step.target}" else "Sir, screen par '${step.target}' tap nahi ho paya (Accessibility chalu hai?).")
            }
            "INPUT_TEXT" -> {
                val ok = JarvisAccessibilityService.inputText(step.target)
                StepOutcome(ok, if (ok) "Text likh diya" else "Sir, text likh nahi paya (Accessibility chalu hai?).")
            }
            "TORCH_ON" -> {
                val ok = DeviceController.toggleFlashlight(context, true)
                _isFlashlightOn.value = DeviceController.isFlashlightActive()
                StepOutcome(ok, if (ok) "Torch ON" else "Sir, torch on nahi ho payi.")
            }
            "TORCH_OFF" -> {
                val ok = DeviceController.toggleFlashlight(context, false)
                _isFlashlightOn.value = DeviceController.isFlashlightActive()
                StepOutcome(ok, if (ok) "Torch OFF" else "Sir, torch band nahi ho payi.")
            }
            "TORCH_TOGGLE" -> {
                val ok = DeviceController.toggleFlashlight(context)
                _isFlashlightOn.value = DeviceController.isFlashlightActive()
                StepOutcome(ok, if (ok) "Torch toggle ho gayi" else "Sir, torch toggle nahi ho payi.")
            }
            "VOLUME_UP" -> {
                val newLevel = DeviceController.adjustVolume(context, true)
                addSystemLog("AUDIO: Volume increased to $newLevel%")
                StepOutcome(newLevel >= 0, "Volume $newLevel%")
            }
            "VOLUME_DOWN" -> {
                val newLevel = DeviceController.adjustVolume(context, false)
                addSystemLog("AUDIO: Volume decreased to $newLevel%")
                StepOutcome(newLevel >= 0, "Volume $newLevel%")
            }
            "HOME" -> gestureOutcome("Home", JarvisAccessibilityService.performHome())
            "BACK" -> gestureOutcome("Back", JarvisAccessibilityService.performBack())
            "RECENTS" -> gestureOutcome("Recents", JarvisAccessibilityService.performRecents())
            "NOTIFICATIONS" -> gestureOutcome("Notifications", JarvisAccessibilityService.performNotifications())
            "LOCK_SCREEN" -> gestureOutcome("Lock screen", JarvisAccessibilityService.performLockScreen())
            "SCREENSHOT" -> gestureOutcome("Screenshot", JarvisAccessibilityService.performScreenshot())
            "SEARCH_WEB" -> {
                val ok = DeviceController.searchWeb(context, step.target)
                StepOutcome(ok, if (ok) "Google search: ${step.target}" else "Sir, web search nahi ho paya.")
            }
            "DIAL_NUMBER" -> {
                val ok = DeviceController.dialNumber(context, step.target)
                StepOutcome(ok, if (ok) "Dialer khul gaya: ${step.target}" else "Sir, dialer nahi khul paya.")
            }
            "OPEN_SETTING" -> {
                val ok = DeviceController.openSettingByName(context, step.target)
                StepOutcome(ok, if (ok) "Settings khul gayi (${step.target})" else "Sir, settings nahi khul payi.")
            }
            "REMEMBER_FACT" -> {
                saveMemory(step.target)
                StepOutcome(true, "Memory me save: ${step.target}")
            }
            else -> StepOutcome(false, "Sir, '${step.actionType}' action mujhe samajh nahi aaya.")
        }
    }

    fun addSystemLog(log: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        _systemLogs.value = listOf("[$time] $log") + _systemLogs.value.take(150)
    }

    fun clearChat() {
        _messages.value = listOf(
            ChatMessage(
                text = "Chat history clear ho gayi hai sir. Main aapki nayi command ke liye taiyar hoon!",
                isJarvis = true
            )
        )
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager?.destroy()
    }
}
