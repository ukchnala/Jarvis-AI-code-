package com.example.data.memory

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "jarvis_memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val content: String,
    val category: String = "GENERAL",
    val timestamp: Long = System.currentTimeMillis()
)
