package com.example.util

import com.example.model.InstalledAppInfo
import java.text.Normalizer
import kotlin.math.max

/** Ek token: original likha hua shabd aur uska roman (matching ke liye) roop. */
data class Tok(val orig: String, val norm: String)

data class AppMatch(val app: InstalledAppInfo, val score: Double)

/**
 * "instgram app open karna" jaise poore vaakya se sirf app ka naam nikalta hai
 * aur installed apps me se sabse milta-julta app dhoondhta hai.
 */
object AppMatcher {

    const val MIN_SCORE = 0.72

    private const val HALANT = '\u094D'

    // Ye shabd app ka naam nahi hote, command ke hisse hote hain.
    private val fillerWords = setOf(
        "open", "opn", "kholo", "kholna", "khol", "kholdo", "kholiye", "kholen", "khulo", "khul",
        "chalao", "chalana", "chala", "chalu", "launch", "start", "run",
        "karo", "kar", "karna", "karne", "kariye", "karen", "karni", "kare", "do", "de", "dena", "dijiye", "diijiye",
        "app", "apps", "application", "aap", "ko", "ka", "ki", "ke", "ek", "the", "a", "an",
        "please", "plz", "pls", "jarvis", "sir", "jao", "jaao", "na", "zara", "mujhe", "mere", "meri", "mera",
        "liye", "hai", "hain", "ho", "to", "bhai", "yaar", "me", "mein", "par", "pe", "se",
        "wala", "wali", "wale", "aur", "and", "then", "phir", "fir", "now", "abhi", "jaldi", "ab",
        "hi", "bhi", "zaroor", "go", "wo", "woh", "vo", "ye", "yeh", "usko", "isko", "isse", "use"
    )

    // Chhote naam / galat bolne ke tareeke -> sahi naam
    private val aliases = mapOf(
        "yt" to "youtube", "utube" to "youtube", "youtub" to "youtube", "tube" to "youtube",
        "wa" to "whatsapp", "whatsap" to "whatsapp", "watsapp" to "whatsapp",
        "fb" to "facebook", "insta" to "instagram", "instgram" to "instagram", "instragram" to "instagram",
        "gpay" to "google pay", "calc" to "calculator", "cam" to "camera",
        "net" to "chrome", "browser" to "chrome", "msg" to "messages", "sms" to "messages",
        "setting" to "settings", "snap" to "snapchat", "tg" to "telegram", "twitter" to "x"
    )

    // Hindi (Devanagari) voice output -> roman. Voice hi-IN me aksar Devanagari aata hai.
    private val devaRaw = mapOf(
        // commands
        "खोलो" to "kholo", "खोल" to "khol", "खोलिए" to "kholiye", "खोलिये" to "kholiye", "खोलना" to "kholna",
        "चलाओ" to "chalao", "चलाना" to "chalana", "चला" to "chala", "चालू" to "chalu", "चालु" to "chalu",
        "ओपन" to "open", "लॉन्च" to "launch", "स्टार्ट" to "start", "बंद" to "band", "बन्द" to "band",
        "करो" to "karo", "कर" to "kar", "करना" to "karna", "दो" to "do", "दे" to "de", "दीजिए" to "dijiye",
        "ऐप" to "app", "एप" to "app", "ऐप्प" to "app", "एप्प" to "app", "ऐप्लिकेशन" to "application", "एप्लिकेशन" to "application",
        "को" to "ko", "का" to "ka", "की" to "ki", "के" to "ke", "एक" to "ek", "मुझे" to "mujhe", "मेरे" to "mere",
        "जाओ" to "jao", "ना" to "na", "है" to "hai", "हैं" to "hain", "में" to "mein", "पर" to "par", "से" to "se",
        "प्लीज" to "please", "जार्विस" to "jarvis", "जारविस" to "jarvis", "सर" to "sir", "भाई" to "bhai", "तो" to "to",
        "और" to "aur", "फिर" to "phir", "फ़िर" to "phir",
        // hardware / gestures
        "टॉर्च" to "torch", "टोर्च" to "torch", "टार्च" to "torch", "फ्लैशलाइट" to "flashlight", "फ्लैश" to "flash",
        "लाइट" to "light", "बत्ती" to "batti", "ऑन" to "on", "ऑफ" to "off", "ओन" to "on", "ओफ" to "off",
        "जलाओ" to "jalao", "जला" to "jala", "बुझाओ" to "bujhao", "बुझा" to "bujha",
        "वॉल्यूम" to "volume", "वोल्यूम" to "volume", "आवाज" to "awaz", "आवाज़" to "awaz", "साउंड" to "sound",
        "बढ़ाओ" to "badhao", "बढाओ" to "badhao", "बढ़ा" to "badha", "कम" to "kam", "घटाओ" to "ghatao", "धीरे" to "dheere",
        "तेज" to "tej", "ज्यादा" to "zyada", "अप" to "up", "डाउन" to "down",
        "होम" to "home", "बैक" to "back", "पीछे" to "peeche", "लॉक" to "lock", "स्क्रीन" to "screen",
        "स्क्रीनशॉट" to "screenshot", "रिसेंट" to "recent", "रीसेंट" to "recent",
        "बैटरी" to "battery", "चार्जिंग" to "charging", "नोटिफिकेशन" to "notification", "नोटिफिकेशंस" to "notifications",
        "सेटिंग" to "settings", "सेटिंग्स" to "settings", "सेटिंग्ज" to "settings",
        "वाईफाई" to "wifi", "वाइफाई" to "wifi", "वाई" to "wi", "फाई" to "fi", "ब्लूटूथ" to "bluetooth", "हॉटस्पॉट" to "hotspot",
        "सर्च" to "search", "गूगल" to "google", "गाना" to "gaana", "गाने" to "gaane", "गान" to "gaana",
        "प्ले" to "play", "वीडियो" to "video", "वीडियोज" to "videos", "कॉल" to "call", "डायल" to "dial",
        "याद" to "yaad", "रखना" to "rakhna", "रखो" to "rakho", "नोट" to "note", "सेव" to "save", "लो" to "lo",
        // small talk
        "नमस्ते" to "namaste", "प्रणाम" to "pranam", "हेलो" to "hello", "हैलो" to "hello", "हाय" to "hi", "हे" to "hey",
        "धन्यवाद" to "dhanyawad", "शुक्रिया" to "shukriya", "थैंक्स" to "thanks", "थैंक" to "thank", "यू" to "you",
        // popular apps
        "इंस्टाग्राम" to "instagram", "इंस्टा" to "instagram", "इन्स्टाग्राम" to "instagram", "इंस्टाग्रम" to "instagram",
        "यूट्यूब" to "youtube", "यूटयूब" to "youtube", "ट्यूब" to "tube",
        "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "वॉट्सऐप" to "whatsapp", "वॉट्सएप" to "whatsapp",
        "वाट्सएप" to "whatsapp", "वाट्सऐप" to "whatsapp", "व्हाट्सएप्प" to "whatsapp",
        "फेसबुक" to "facebook", "फ़ेसबुक" to "facebook", "स्नैपचैट" to "snapchat", "टेलीग्राम" to "telegram",
        "ट्विटर" to "twitter", "क्रोम" to "chrome", "कैमरा" to "camera", "कैलकुलेटर" to "calculator",
        "गैलरी" to "gallery", "फोटो" to "photos", "फोटोज" to "photos", "मैप्स" to "maps", "मैप" to "maps",
        "जीमेल" to "gmail", "नेटफ्लिक्स" to "netflix", "स्पॉटिफाई" to "spotify", "अमेज़न" to "amazon", "अमेजन" to "amazon",
        "फ्लिपकार्ट" to "flipkart", "पेटीएम" to "paytm", "फोनपे" to "phonepe", "जीपे" to "gpay", "हॉटस्टार" to "hotstar",
        "घड़ी" to "clock", "क्लॉक" to "clock", "म्यूजिक" to "music", "संदेश" to "messages", "मैसेज" to "messages",
        "फोन" to "phone", "कांटेक्ट" to "contacts", "कॉन्टैक्ट" to "contacts", "कॉन्टेक्ट्स" to "contacts"
    )

    private val devaWords: Map<String, String> by lazy {
        devaRaw.mapKeys { stripMarks(it.key) }
    }

    private val consonants = mapOf(
        'क' to "k", 'ख' to "kh", 'ग' to "g", 'घ' to "gh", 'ङ' to "n",
        'च' to "ch", 'छ' to "chh", 'ज' to "j", 'झ' to "jh", 'ञ' to "n",
        'ट' to "t", 'ठ' to "th", 'ड' to "d", 'ढ' to "dh", 'ण' to "n",
        'त' to "t", 'थ' to "th", 'द' to "d", 'ध' to "dh", 'न' to "n",
        'प' to "p", 'फ' to "f", 'ब' to "b", 'भ' to "bh", 'म' to "m",
        'य' to "y", 'र' to "r", 'ल' to "l", 'व' to "v", 'श' to "sh", 'ष' to "sh", 'स' to "s", 'ह' to "h"
    )

    private val independentVowels = mapOf(
        'अ' to "a", 'आ' to "a", 'इ' to "i", 'ई' to "i", 'उ' to "u", 'ऊ' to "u", 'ऋ' to "ri",
        'ए' to "e", 'ऐ' to "ai", 'ओ' to "o", 'औ' to "au", 'ऑ' to "o"
    )

    private val matras = mapOf(
        'ा' to "a", 'ि' to "i", 'ी' to "i", 'ु' to "u", 'ू' to "u", 'ृ' to "ri",
        'े' to "e", 'ै' to "ai", 'ो' to "o", 'ौ' to "au", 'ॉ' to "o", 'ॅ' to "e", 'ॆ' to "e", 'ॊ' to "o"
    )

    private val genericPackageParts = setOf(
        "com", "org", "net", "io", "in", "android", "app", "apps", "mobile", "free", "lite",
        "google", "samsung", "miui", "xiaomi", "oneplus", "oppo", "vivo", "realme", "huawei", "sec"
    )

    // ---------------------------------------------------------------- tokens

    private fun isDevanagari(ch: Char): Boolean =
        ch in '\u0900'..'\u097F' && ch != '\u0964' && ch != '\u0965'

    private fun hasDevanagari(s: String): Boolean = s.any { isDevanagari(it) }

    /** Nukta hata kar, combining marks ko ek roop me laata hai. */
    private fun stripMarks(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD).replace("\u093C", "")

    private fun transliterate(word: String): String {
        val s = stripMarks(word)
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val c = s[i]
            val cons = consonants[c]
            if (cons != null) {
                sb.append(cons)
                val next = if (i + 1 < s.length) s[i + 1] else null
                if (next == HALANT) {
                    i++
                } else if (next != null && matras.containsKey(next)) {
                    sb.append(matras[next] ?: "")
                    i++
                } else if (next != null) {
                    sb.append('a')
                }
            } else if (independentVowels.containsKey(c)) {
                sb.append(independentVowels[c] ?: "")
            } else if (c == 'ं' || c == 'ँ') {
                sb.append('n')
            } else if (c == 'ः') {
                sb.append('h')
            } else if (c.code < 128) {
                sb.append(c.lowercaseChar())
            }
            i++
        }
        return sb.toString()
    }

    /** Text ko shabdon me todta hai. Devanagari shabd roman me badal diye jaate hain. */
    fun tokenize(raw: String): List<Tok> {
        val cleaned = raw.replace("'", "").replace("’", "")
            .map { ch -> if (ch.isLetterOrDigit() || isDevanagari(ch)) ch else ' ' }
            .joinToString("")
        val result = mutableListOf<Tok>()
        for (w in cleaned.split(' ')) {
            if (w.isBlank()) continue
            val lower = w.lowercase()
            if (hasDevanagari(lower)) {
                val mapped = devaWords[stripMarks(lower)] ?: transliterate(lower)
                if (mapped.isNotBlank()) result.add(Tok(w, mapped))
            } else {
                result.add(Tok(w, lower))
            }
        }
        return result
    }

    private fun normText(s: String): String = tokenize(s).joinToString(" ") { it.norm }

    private fun alias(token: String): String = aliases[token] ?: token

    /** "instgram app open karna" -> "instagram" */
    fun cleanAppName(raw: String): String =
        tokenize(raw).map { it.norm }
            .filter { it !in fillerWords }
            .joinToString(" ") { alias(it) }
            .trim()

    private fun candidatesFor(raw: String): List<String> {
        val toks = tokenize(raw).map { it.norm }
        val withoutFiller = toks.filter { it !in fillerWords }.joinToString(" ") { alias(it) }.trim()
        // "whats app" jaise toote hue naam ke liye: "app" rakh kar jod do
        val joined = toks.filter { it !in fillerWords || it == "app" || it == "apps" }
            .joinToString("") { alias(it) }.trim()
        return listOf(withoutFiller, joined).filter { it.isNotBlank() }.distinct()
    }

    // ---------------------------------------------------------------- scoring

    private fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            val tmp = prev
            prev = cur
            cur = tmp
        }
        return prev[b.length]
    }

    private fun similarity(a: String, b: String): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        return 1.0 - levenshtein(a, b).toDouble() / max(a.length, b.length)
    }

    /** Awaaz ke hisaab se dhaancha: vowels hata do, milti-julti awaazein ek karo. */
    private fun skeleton(s: String): String {
        var x = s.replace(" ", "")
            .replace("ph", "f").replace("ck", "k").replace("w", "v")
            .replace("c", "k").replace("q", "k").replace("x", "ks")
        x = x.filter { it !in "aeiouyh" }
        val sb = StringBuilder()
        for (ch in x) {
            if (sb.isEmpty() || sb[sb.length - 1] != ch) sb.append(ch)
        }
        return sb.toString()
    }

    private fun scoreAgainst(q: String, qSkel: String, t: String): Double {
        if (q.isEmpty() || t.isEmpty()) return 0.0
        if (q == t) return 1.0
        var best = 0.0
        if (q.length >= 3 && t.startsWith(q)) {
            best = max(best, 0.90)
        } else if (q.length >= 3 && t.contains(q)) {
            best = max(best, 0.80)
        }
        // poore vaakya me app ka naam maujood ho
        if (t.length >= 3 && " $q ".contains(" $t ")) best = max(best, 0.88)
        best = max(best, similarity(q, t) * 0.95)
        for (tok in t.split(' ')) {
            if (tok.length >= 3) best = max(best, similarity(q, tok) * 0.92)
        }
        val tSkel = skeleton(t)
        if (qSkel.length >= 3 && tSkel.length >= 3) {
            best = if (qSkel == tSkel) max(best, 0.84) else max(best, similarity(qSkel, tSkel) * 0.8)
        }
        return best
    }

    private fun packageKeyword(pkg: String): String =
        pkg.lowercase().split('.').filter { it.isNotBlank() && it !in genericPackageParts }.lastOrNull() ?: ""

    private fun scoreApp(candidates: List<Pair<String, String>>, app: InstalledAppInfo, labelNorm: String): Double {
        val pkgKey = packageKeyword(app.packageName)
        var best = 0.0
        for ((q, qSkel) in candidates) {
            best = max(best, scoreAgainst(q, qSkel, labelNorm))
            if (pkgKey.isNotEmpty()) best = max(best, scoreAgainst(q, qSkel, pkgKey) * 0.9)
        }
        return best
    }

    private fun rank(query: String, apps: List<InstalledAppInfo>): List<AppMatch> {
        val cands = candidatesFor(query).map { it to skeleton(it) }
        if (cands.isEmpty()) return emptyList()
        return apps.map { app ->
            AppMatch(app, scoreApp(cands, app, normText(app.label)))
        }.sortedWith(compareByDescending<AppMatch> { it.score }.thenBy { it.app.label.length })
    }

    /** Sabse milta hua app, ya MIN_SCORE se kam milne par null. */
    fun findBest(query: String, apps: List<InstalledAppInfo>, minScore: Double = MIN_SCORE): AppMatch? {
        val trimmed = query.trim()
        apps.firstOrNull { it.packageName.equals(trimmed, ignoreCase = true) }?.let { return AppMatch(it, 1.0) }
        val top = rank(query, apps).firstOrNull() ?: return null
        return if (top.score >= minScore) top else null
    }

    /** "Kya aap ye keh rahe the?" ke liye kuch milte-julte apps. */
    fun suggest(query: String, apps: List<InstalledAppInfo>, limit: Int = 3): List<InstalledAppInfo> =
        rank(query, apps).filter { it.score >= 0.5 }.take(limit).map { it.app }
}
