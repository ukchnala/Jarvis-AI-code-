package com.example.util

import android.content.Context
import com.example.model.InstalledAppInfo

/**
 * Gemini se pehle chalne wale tez local niyam.
 * Koi niyam match ho to turant (internet ke bina) steps ka plan milta hai.
 * Match na ho to null -> tab hi Gemini ko bulaya jaata hai.
 */
object LocalCommandRouter {

    private val connectors = setOf("aur", "phir", "fir", "then", "and", "uske", "baad")

    private val memoryRegexes = listOf(
        Regex("(?i)\\byaad\\s+rakh(?:na|o|iye|ana)?(?:\\s+ki)?\\b"),
        Regex("(?i)\\b(?:note|save)\\s+kar\\s+lo\\b"),
        Regex("याद\\s+रख(?:ना|ो|िए)?(?:\\s+कि)?")
    )

    fun route(input: String, context: Context?, installedApps: List<InstalledAppInfo>): GeminiExecutionResult? {
        val tokens = AppMatcher.tokenize(input)
        if (tokens.isEmpty()) return null

        routeGreedy(input, tokens)?.let { return it }

        val segments = splitCompound(tokens)
        if (segments.size > 1) {
            val parts = segments.map { routeSingle(null, it, context, installedApps) }
            if (parts.any { it == null }) return null
            return merge(parts.filterNotNull())
        }
        return routeSingle(input, tokens, context, installedApps)
    }

    // ------------------------------------------------------------ helpers

    private fun result(reply: String, steps: List<JarvisExecutionStep> = emptyList(), memory: String? = null) =
        GeminiExecutionResult(
            hinglishReply = reply,
            steps = steps,
            newMemoryToSave = memory,
            source = "LOCAL"
        )

    private fun step(type: String, target: String, description: String, pkg: String = "") =
        JarvisExecutionStep(actionType = type, target = target, description = description, packageName = pkg)

    private fun splitCompound(tokens: List<Tok>): List<List<Tok>> {
        val out = mutableListOf<List<Tok>>()
        var cur = mutableListOf<Tok>()
        for (t in tokens) {
            if (t.norm in connectors) {
                if (cur.isNotEmpty()) out.add(cur)
                cur = mutableListOf()
            } else {
                cur.add(t)
            }
        }
        if (cur.isNotEmpty()) out.add(cur)
        return out
    }

    private fun merge(parts: List<GeminiExecutionResult>): GeminiExecutionResult =
        GeminiExecutionResult(
            hinglishReply = parts.joinToString(" ") { it.hinglishReply },
            steps = parts.flatMap { it.steps },
            newMemoryToSave = parts.firstNotNullOfOrNull { it.newMemoryToSave },
            source = "LOCAL"
        )

    // ------------------------------------------------------------ rules that need the whole sentence

    private fun routeGreedy(input: String?, tokens: List<Tok>): GeminiExecutionResult? {
        if (input != null) routeMemory(input)?.let { return it }
        routeYouTube(tokens)?.let { return it }
        routeWebSearch(tokens)?.let { return it }
        routeCall(tokens)?.let { return it }
        return null
    }

    private fun routeMemory(input: String): GeminiExecutionResult? {
        if (memoryRegexes.none { it.containsMatchIn(input) }) return null
        var fact = input
        for (r in memoryRegexes) fact = r.replace(fact, " ")
        fact = fact.replace(Regex("\\s+"), " ").trim()
        if (fact.isBlank()) fact = input.trim()
        return result(
            reply = "Ji sir, maine ye hamesha ke liye yaad rakh liya.",
            steps = listOf(step("REMEMBER_FACT", fact, "Memory Vault me save karna")),
            memory = fact
        )
    }

    private val ytWords = setOf("youtube", "yt", "utube", "youtub")
    private val ytActionWords = setOf(
        "search", "gaana", "gana", "gane", "gaane", "song", "songs", "play", "chalao", "chala", "laga", "lagao",
        "dhundo", "dhoondo", "dekho", "sunao", "suno", "video", "videos", "dikhao"
    )
    private val ytPlayWords = setOf("play", "chalao", "chala", "laga", "lagao", "sunao", "suno")
    private val ytStopWords = ytWords + setOf(
        "you", "tube", "kholo", "khol", "kholkar", "open", "launch", "par", "pe", "me", "mein", "aur", "and",
        "then", "phir", "fir", "search", "karo", "kar", "karna", "ke", "ki", "ka", "ko", "gaana", "gana", "gane",
        "gaane", "song", "songs", "play", "chalao", "chala", "laga", "lagao", "dhundo", "dhoondo", "dekho",
        "sunao", "suno", "video", "videos", "dikhao", "do", "de", "please", "plz", "jarvis", "sir", "na",
        "wala", "wali", "ek", "mujhe", "zara", "k", "hai", "ho", "to", "se", "ab", "abhi"
    )

    private fun routeYouTube(tokens: List<Tok>): GeminiExecutionResult? {
        val norms = tokens.map { it.norm }
        val hasYt = norms.any { it in ytWords } || norms.zipWithNext().any { it.first == "you" && it.second == "tube" }
        if (!hasYt) return null
        if (norms.none { it in ytActionWords }) return null // sirf "youtube kholo" -> app launch wala niyam

        val termTokens = tokens.filter { it.norm !in ytStopWords }.map { it.orig }
        var term = termTokens.joinToString(" ").trim()
        val wantsSongs = norms.any { it in setOf("gaana", "gana", "gane", "gaane", "song", "songs") }
        if (term.isNotBlank() && wantsSongs) term = "$term songs"

        val launch = step("LAUNCH_APP", "YouTube", "YouTube application open karna")
        if (term.isBlank()) {
            return result(
                reply = "Ji sir, YouTube khol raha hoon. Kya search karna hai?",
                steps = listOf(launch)
            )
        }
        val steps = mutableListOf(
            launch,
            step("SEARCH_YOUTUBE", term, "YouTube me '$term' search karna")
        )
        if (norms.any { it in ytPlayWords }) {
            steps.add(step("CLICK_TEXT", term, "Pehla result tap karna"))
        }
        return result(reply = "Ji sir, YouTube par '$term' dhoondh raha hoon.", steps = steps)
    }

    private val webStopWords = setOf(
        "search", "google", "for", "karo", "kar", "karna", "par", "pe", "ke", "baare", "bare", "mein", "me",
        "ka", "ki", "ko", "pata", "do", "de", "please", "plz", "jarvis", "sir", "dhundo", "dhoondo", "internet", "net"
    )

    private fun routeWebSearch(tokens: List<Tok>): GeminiExecutionResult? {
        val norms = tokens.map { it.norm }
        val first = norms.first()
        val lastTwo = norms.takeLast(2)
        val startsWithTrigger = first == "search" || first == "google" || first == "dhundo" || first == "dhoondo"
        val endsWithTrigger = lastTwo.size == 2 &&
            ((lastTwo[0] == "search" && lastTwo[1] in setOf("karo", "kar")) ||
                (lastTwo[0] == "google" && lastTwo[1] in setOf("karo", "kar")) ||
                (lastTwo[0] == "pata" && lastTwo[1] in setOf("karo", "kar")))
        if (!startsWithTrigger && !endsWithTrigger) return null
        // "google maps kholo" jaisa command web search nahi, app launch hai
        if (norms.any { it in strongOpenWords || it in weakOpenWords }) return null

        val term = tokens.filter { it.norm !in webStopWords }.joinToString(" ") { it.orig }.trim()
        if (term.isBlank()) return null
        return result(
            reply = "Ji sir, Google par '$term' search kar raha hoon.",
            steps = listOf(step("SEARCH_WEB", term, "Google par '$term' search karna"))
        )
    }

    private fun routeCall(tokens: List<Tok>): GeminiExecutionResult? {
        val norms = tokens.map { it.norm }
        val isCall = norms.first() == "call" || norms.first() == "dial" ||
            norms.zipWithNext().any { it.first == "call" && it.second in setOf("karo", "kar") }
        if (!isCall) return null
        val digits = tokens.joinToString("") { it.norm }.filter { it.isDigit() }
        if (digits.length < 3) return null // naam se call -> Gemini/user se poochho
        return result(
            reply = "Ji sir, $digits ka dialer khol raha hoon.",
            steps = listOf(step("DIAL_NUMBER", digits, "$digits dial karna"))
        )
    }

    // ------------------------------------------------------------ simple one-command rules

    private fun routeSingle(
        input: String?,
        tokens: List<Tok>,
        context: Context?,
        installedApps: List<InstalledAppInfo>
    ): GeminiExecutionResult? {
        if (tokens.isEmpty()) return null
        routeGreedy(input, tokens)?.let { return it }

        val norms = tokens.map { it.norm }
        val set = norms.toSet()
        val text = norms.joinToString(" ")
        val padded = " $text "
        fun p(vararg phrases: String) = phrases.any { padded.contains(" $it ") }

        // --- Torch
        val onWord = set.any { it in setOf("on", "jalao", "jala", "chalu", "chalao", "chala", "start", "enable") }
        val offWord = set.any { it in setOf("off", "band", "bujhao", "bujha", "stop", "disable") }
        val torchWord = set.any { it in setOf("torch", "flashlight", "flash", "batti", "torchlight", "tourch") }
        val lightWord = "light" in set
        if (torchWord || (lightWord && (onWord || offWord))) {
            if (offWord) {
                return result(
                    "Ji sir, torch band kar di hai.",
                    listOf(step("TORCH_OFF", "", "Flashlight OFF karna"))
                )
            }
            if (onWord) {
                return result(
                    "Ji sir, torch on kar di hai.",
                    listOf(step("TORCH_ON", "", "Flashlight ON karna"))
                )
            }
            if (torchWord) {
                return result(
                    "Ji sir, torch toggle kar raha hoon.",
                    listOf(step("TORCH_TOGGLE", "", "Flashlight toggle karna"))
                )
            }
        }

        // --- Volume
        val volWord = set.any { it in setOf("volume", "awaz", "aawaz", "avaz", "sound") }
        if (volWord) {
            val down = set.any { it in setOf("down", "kam", "ghatao", "ghata", "decrease", "dheere", "dhire", "low", "reduce", "halka") }
            val up = set.any { it in setOf("up", "badhao", "badha", "badhana", "increase", "tej", "zyada", "jyada", "loud", "full", "more") }
            if (down) {
                return result("Ji sir, volume kam kar diya.", listOf(step("VOLUME_DOWN", "", "Volume kam karna")))
            }
            if (up) {
                return result("Ji sir, volume badha diya.", listOf(step("VOLUME_UP", "", "Volume badhana")))
            }
        }

        // --- Gestures
        if (text == "home" || p("home screen", "go home", "home jao", "home par", "home pe", "ghar jao")) {
            return result("Ji sir, home screen par ja raha hoon.", listOf(step("HOME", "", "Home gesture")))
        }
        if (text == "back" || p("go back", "back jao", "back karo", "peeche jao", "piche jao", "wapas jao")) {
            return result("Ji sir, peeche ja raha hoon.", listOf(step("BACK", "", "Back gesture")))
        }
        if (p("recent apps", "recent app", "recents", "multitasking", "recent screen", "background apps")) {
            return result("Ji sir, recent apps dikha raha hoon.", listOf(step("RECENTS", "", "Recents kholna")))
        }
        if (set.any { it == "notification" || it == "notifications" || it == "notif" }) {
            return result("Ji sir, notifications khol raha hoon.", listOf(step("NOTIFICATIONS", "", "Notification shade kholna")))
        }
        if (p("lock screen", "screen lock", "phone lock", "lock karo", "lock kar do", "screen band karo", "phone band karo")) {
            return result("Ji sir, phone lock kar raha hoon.", listOf(step("LOCK_SCREEN", "", "Screen lock karna")))
        }
        if (set.any { it == "screenshot" || it == "screenshots" } || p("screen shot", "screen capture", "capture screen")) {
            return result("Ji sir, screenshot le raha hoon.", listOf(step("SCREENSHOT", "", "Screenshot lena")))
        }

        // --- Battery (jawab turant, kisi step ki zaroorat nahi)
        if (context != null && set.any { it == "battery" || it == "charging" || it == "charge" }) {
            val (level, charging) = DeviceController.getBatteryInfo(context)
            val state = if (charging) "charging par laga hai" else "battery par chal raha hai"
            return result("Sir, battery $level percent hai aur phone $state.")
        }

        // --- Settings shortcuts
        if (text.contains("wifi") || p("wi fi") || "hotspot" in set) {
            return result("Ji sir, Wi-Fi settings khol raha hoon.", listOf(step("OPEN_SETTING", "wifi", "Wi-Fi settings kholna")))
        }
        if ("bluetooth" in set) {
            return result("Ji sir, Bluetooth settings khol raha hoon.", listOf(step("OPEN_SETTING", "bluetooth", "Bluetooth settings kholna")))
        }
        if (("settings" in set || "setting" in set) && (text == "settings" || text == "setting" || set.any { it in strongOpenWords })) {
            return result("Ji sir, settings khol raha hoon.", listOf(step("OPEN_SETTING", "settings", "Settings kholna")))
        }

        // --- Small talk
        smallTalk(text, padded)?.let { return result(it) }

        // --- Koi bhi installed app kholna
        return routeOpenApp(tokens, installedApps)
    }

    private val strongOpenWords = setOf("open", "kholo", "khol", "kholna", "kholiye", "kholen", "launch", "khulo", "khul")
    private val weakOpenWords = setOf("chalao", "chalana", "chala", "start", "run")
    private val bareNameBlocklist = setOf("play", "stop", "pause", "next", "yes", "no", "ok", "okay", "haan", "nahi", "kya", "kyun")

    private fun routeOpenApp(tokens: List<Tok>, apps: List<InstalledAppInfo>): GeminiExecutionResult? {
        val norms = tokens.map { it.norm }
        val strong = norms.any { it in strongOpenWords }
        val weak = norms.any { it in weakOpenWords }

        val name = AppMatcher.cleanAppName(norms.joinToString(" "))
        if (name.isBlank()) return null
        if (name.split(' ').size > 3) return null // lamba vaakya -> Gemini samjhega

        if (!strong && !weak) {
            // Sirf naam bola ho ("instagram") -> tabhi kholo jab match bahut pakka ho
            if (norms.size > 2 || name in bareNameBlocklist) return null
            val strict = AppMatcher.findBest(name, apps, 0.9) ?: return null
            return launchResult(strict)
        }

        val match = AppMatcher.findBest(name, apps)
        if (match != null) return launchResult(match)
        if (apps.isEmpty()) return null // list nahi mili -> Gemini/ViewModel sambhalega
        if (weak && !strong) return null // "gaana chalao" jaisa kuch -> Gemini

        val suggestions = AppMatcher.suggest(name, apps, 3).joinToString(", ") { it.label }
        val extra = if (suggestions.isNotBlank()) " Milte-julte apps: $suggestions." else ""
        return result("Sir, '$name' naam ka app mujhe phone mein nahi mila.$extra")
    }

    private fun launchResult(match: AppMatch): GeminiExecutionResult =
        result(
            reply = "Ji sir, ${match.app.label} khol raha hoon.",
            steps = listOf(
                step("LAUNCH_APP", match.app.label, "${match.app.label} open karna", match.app.packageName)
            )
        )

    private fun smallTalk(text: String, padded: String): String? {
        fun p(vararg phrases: String) = phrases.any { padded.contains(" $it ") }
        return when {
            p("tum kaun ho", "kaun ho tum", "who are you", "aap kaun ho") ->
                "Main JARVIS hoon, sir! Aapka personal AI assistant. Phone ke apps, torch, volume, search aur bahut kuch kar sakta hoon."
            p("kya kar sakte ho", "tum kya kar sakte ho", "what can you do") ->
                "Sir, main koi bhi app khol sakta hoon, torch, volume, gestures, battery, search aur YouTube sab kar sakta hoon."
            p("kaise ho", "kya haal hai", "how are you") ->
                "Main bilkul badhiya hoon, sir! Boliye, kya karna hai?"
            p("namaste", "pranam", "namaskar") ->
                "Namaste sir! Jarvis online hai. Boliye, kya karna hai?"
            p("dhanyawad", "thank you", "thanks", "shukriya") ->
                "Aapka swagat hai sir!"
            p("good morning", "shubh prabhat") ->
                "Good morning sir! Aapka din shandaar ho."
            p("good night", "shubh ratri") ->
                "Good night sir! Main background me phone ka dhyan rakhunga."
            p("joke sunao", "chutkula", "hasao") ->
                "Ek phone doosre se bola: 'Teri battery jaldi kyu khatam hoti hai?' Doosra bola: 'Pure din reels dekhta hoon!'"
            text in setOf("hello", "hi", "hey", "jarvis", "hello jarvis", "hi jarvis", "hey jarvis", "wake up", "sun rahe ho", "kuch bolo") ->
                "Haan sir, main active hoon! Boliye, kya kaam hai?"
            else -> null
        }
    }
}
