package com.example.util

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import com.example.model.InstalledAppInfo

object DeviceController {

    private var isTorchOn = false

    fun toggleFlashlight(context: Context, forceState: Boolean? = null): Boolean {
        return try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
                ?: return false
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                val chars = cameraManager.getCameraCharacteristics(id)
                chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: cameraManager.cameraIdList.firstOrNull() ?: return false

            val newState = forceState ?: !isTorchOn
            cameraManager.setTorchMode(cameraId, newState)
            isTorchOn = newState
            vibrate(context, 50)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun isFlashlightActive(): Boolean = isTorchOn

    fun getBatteryInfo(context: Context): Pair<Int, Boolean> {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val level = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: 85
        val isCharging = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val status = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_STATUS) ?: -1
            status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        } else {
            false
        }
        return Pair(level.coerceIn(0, 100), isCharging)
    }

    fun adjustVolume(context: Context, increase: Boolean): Int {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return -1
        val direction = if (increase) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
        vibrate(context, 30)
        val current = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        return if (max > 0) (current * 100) / max else 50
    }

    @Volatile
    private var appCache: List<InstalledAppInfo> = emptyList()

    @Volatile
    private var appCacheTime = 0L

    fun getInstalledApps(context: Context): List<InstalledAppInfo> {
        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolved = pm.queryIntentActivities(mainIntent, 0)
        val appList = mutableListOf<InstalledAppInfo>()

        for (resolveInfo in resolved) {
            val packageName = resolveInfo.activityInfo.packageName
            val label = resolveInfo.loadLabel(pm).toString()
            val isSystem = (resolveInfo.activityInfo.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            if (packageName != context.packageName) {
                appList.add(InstalledAppInfo(label = label, packageName = packageName, isSystem = isSystem))
            }
        }
        val result = appList.distinctBy { it.packageName }.sortedBy { it.label.lowercase() }
        appCache = result
        appCacheTime = System.currentTimeMillis()
        return result
    }

    /** Har command par PackageManager dobara na poochna pade, isliye 60 second ka cache. */
    fun getInstalledAppsCached(context: Context, maxAgeMs: Long = 60_000L): List<InstalledAppInfo> {
        val cached = appCache
        if (cached.isNotEmpty() && System.currentTimeMillis() - appCacheTime < maxAgeMs) return cached
        return getInstalledApps(context)
    }

    private fun resolveLaunchIntent(context: Context, packageName: String): Intent? {
        val pm = context.packageManager
        pm.getLaunchIntentForPackage(packageName)?.let { return it }
        // Kuch apps ke liye getLaunchIntentForPackage null deta hai; launcher activity khud dhoondo.
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage(packageName)
        val info = pm.queryIntentActivities(query, 0).firstOrNull() ?: return null
        return Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(info.activityInfo.packageName, info.activityInfo.name)
    }

    fun launchApp(context: Context, packageName: String): Boolean {
        return try {
            val intent = resolveLaunchIntent(context, packageName) ?: return false
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            context.startActivity(intent)
            vibrate(context, 50)
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Installed apps me se sabse milta naam (galat spelling / poora vaakya bhi chalega). */
    fun findAppByName(context: Context, query: String): InstalledAppInfo? =
        AppMatcher.findBest(query, getInstalledAppsCached(context))?.app

    fun openSettingByName(context: Context, name: String): Boolean {
        val n = name.lowercase()
        val action = when {
            "wifi" in n || "wi-fi" in n || "hotspot" in n -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" in n -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" in n || "brightness" in n -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" in n || "volume" in n -> Settings.ACTION_SOUND_SETTINGS
            "location" in n || "gps" in n -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "airplane" in n || "flight" in n -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
            "mobile" in n || "network" in n -> Settings.ACTION_WIRELESS_SETTINGS
            "battery" in n -> Intent.ACTION_POWER_USAGE_SUMMARY
            else -> Settings.ACTION_SETTINGS
        }
        return openSystemSetting(context, action)
    }

    fun openSystemSetting(context: Context, action: String): Boolean {
        return try {
            val intent = Intent(action).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            vibrate(context, 40)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun searchYouTube(context: Context, query: String): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_SEARCH).apply {
                setPackage("com.google.android.youtube")
                putExtra("query", query)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (intent.resolveActivity(context.packageManager) != null) {
                context.startActivity(intent)
                vibrate(context, 50)
                true
            } else {
                openUrl(context, "https://www.youtube.com/results?search_query=${Uri.encode(query)}")
            }
        } catch (e: Exception) {
            openUrl(context, "https://www.youtube.com/results?search_query=${Uri.encode(query)}")
        }
    }

    fun searchWeb(context: Context, query: String): Boolean {
        return try {
            val searchIntent = Intent(Intent.ACTION_WEB_SEARCH).apply {
                putExtra("query", query)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(searchIntent)
            vibrate(context, 40)
            true
        } catch (e: Exception) {
            openUrl(context, "https://www.google.com/search?q=${Uri.encode(query)}")
        }
    }

    fun openUrl(context: Context, url: String): Boolean {
        return try {
            val uri = if (url.startsWith("http://") || url.startsWith("https://")) {
                Uri.parse(url)
            } else {
                Uri.parse("https://$url")
            }
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            vibrate(context, 40)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun dialNumber(context: Context, number: String): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(number)}")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            vibrate(context, 40)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun vibrate(context: Context, durationMs: Long = 40) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val v = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v?.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    v?.vibrate(durationMs)
                }
            }
        } catch (e: Exception) {
            // Safe ignore
        }
    }
}
