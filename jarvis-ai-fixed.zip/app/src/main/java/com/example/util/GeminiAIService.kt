package com.example.util

import android.content.Context
import android.util.Log
import com.example.BuildConfig
import com.example.data.memory.MemoryEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class JarvisExecutionStep(
    val actionType: String,
    val target: String = "",
    val description: String,
    /** Agar app pehle se pehchana ja chuka ho to uska package (launch seedha ho jaata hai). */
    val packageName: String = ""
)

data class GeminiExecutionResult(
    val hinglishReply: String,
    val steps: List<JarvisExecutionStep>,
    val newMemoryToSave: String? = null,
    /** LOCAL = tez local niyam, GEMINI = AI jawab, FALLBACK = kuch match nahi hua */
    val source: String = "GEMINI",
    /** Gemini fail hua to yahan wajah aati hai (LOGS me dikhai jaati hai). */
    val note: String? = null
)

object GeminiAIService {
    private const val TAG = "GeminiAIService"

    // Pehla model chalta hai, 404/400 par agla try hota hai.
    private val MODELS = listOf("gemini-3.8-flash", "gemini-flash-latest")

    private val httpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(6, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .writeTimeout(8, TimeUnit.SECONDS)
            .callTimeout(20, TimeUnit.SECONDS)
            .build()
    }

    fun getApiKey(context: Context): String {
        val prefKey = context.getSharedPreferences("jarvis_prefs", Context.MODE_PRIVATE)
            .getString("custom_gemini_api_key", "") ?: ""
        if (prefKey.isNotBlank()) return prefKey

        val buildKey = BuildConfig.GEMINI_API_KEY
        if (buildKey.isNotBlank() && buildKey != "MY_GEMINI_API_KEY") {
            return buildKey
        }
        return ""
    }

    fun isConfigured(context: Context): Boolean {
        return getApiKey(context).isNotBlank()
    }

    suspend fun executeComplexCommand(
        prompt: String,
        context: Context,
        installedApps: List<String>,
        memories: List<MemoryEntity>
    ): GeminiExecutionResult = withContext(Dispatchers.IO) {
        val apiKey = getApiKey(context)
        if (apiKey.isBlank()) {
            return@withContext fallbackParse(prompt).copy(
                note = "Gemini API key set nahi hai. Key daalne ke baad AI commands chalenge."
            )
        }

        try {
            val systemText = buildSystemInstruction(installedApps, memories)
            var lastError = "Gemini se jawab nahi mila"

            for (model in MODELS) {
                var useThinking = true
                while (true) {
                    val (code, raw) = post(model, apiKey, buildBody(systemText, prompt, useThinking))
                    if (code in 200..299) {
                        val text = extractText(raw)
                        if (text.isBlank()) {
                            return@withContext fallbackParse(prompt).copy(note = "Gemini ne khali jawab diya ($model)")
                        }
                        return@withContext parseGeminiJson(text, prompt)
                    }
                    lastError = "HTTP $code ($model): ${raw.take(200)}"
                    Log.e(TAG, "Gemini API error: $lastError")
                    if (code == 400 && useThinking) {
                        useThinking = false // thinkingConfig na chale to bina uske dobara
                        continue
                    }
                    if (code == 400 || code == 404) break // agla model try karo
                    // 401/403/429/5xx: model badalne se fayda nahi
                    return@withContext fallbackParse(prompt).copy(note = lastError)
                }
            }
            fallbackParse(prompt).copy(note = lastError)
        } catch (e: Exception) {
            Log.e(TAG, "Gemini call exception", e)
            fallbackParse(prompt).copy(note = "Gemini call fail: ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    private fun post(model: String, apiKey: String, body: JSONObject): Pair<Int, String> {
        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .header("x-goog-api-key", apiKey)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        return httpClient.newCall(request).execute().use { response ->
            Pair(response.code, response.body?.string().orEmpty())
        }
    }

    private fun buildSystemInstruction(installedApps: List<String>, memories: List<MemoryEntity>): String {
        val memoryContext = if (memories.isNotEmpty()) {
            "Permanent memories saved by user:\n" +
                memories.take(30).joinToString("\n") { "- [ID ${it.id}] ${it.content}" }
        } else {
            "No prior memories saved yet."
        }

        return """
            You are J.A.R.V.I.S., an Android phone assistant. Convert the user's command into JSON.

            $memoryContext

            Installed apps on this phone (use these exact names): ${installedApps.take(150).joinToString(", ")}.

            ALLOWED ACTION TYPES:
            - "LAUNCH_APP": open an app. "target" = ONLY the app name, 1-2 words, copied from the installed apps list (e.g. "Instagram"). NEVER a sentence, never words like open/kholo/karna/app. If the user misspells it ("instgram"), write the correct installed name.
            - "SEARCH_YOUTUBE": search inside YouTube. "target" = search query.
            - "CLICK_TEXT": tap text/button on screen. "target" = the text.
            - "INPUT_TEXT": type text in the active field. "target" = the text.
            - "TORCH_ON", "TORCH_OFF", "VOLUME_UP", "VOLUME_DOWN", "HOME", "BACK", "RECENTS", "NOTIFICATIONS", "LOCK_SCREEN", "SCREENSHOT": "target" = "".
            - "OPEN_SETTING": "target" = one of wifi, bluetooth, display, sound, location, airplane, battery, settings.
            - "SEARCH_WEB": Google search. "target" = query.
            - "DIAL_NUMBER": open dialer. "target" = phone number.
            - "REMEMBER_FACT": save a fact permanently. "target" = the fact.

            RULES:
            - "reply" = short Hinglish answer (max 2 sentences) spoken to the user.
            - If the command needs a phone action, put it in "steps" (in order). If it is just a question or chat, "steps" = [] and answer it in "reply".
            - "description" = max 5 words.
            - "new_memory" = fact string only if the user asked to remember something, else null.

            EXAMPLES:
            - "instagram kholo" -> {"reply":"Ji sir, Instagram khol raha hoon.","new_memory":null,"steps":[{"action":"LAUNCH_APP","target":"Instagram","description":"Instagram kholna"}]}
            - "torch on karo aur volume badhao" -> {"reply":"Ji sir, torch on aur volume up.","new_memory":null,"steps":[{"action":"TORCH_ON","target":"","description":"Torch on"},{"action":"VOLUME_UP","target":"","description":"Volume up"}]}
            - "YouTube kholo aur Arijit Singh ke gaane chalao" -> {"reply":"Ji sir, YouTube par Arijit Singh ke gaane chala raha hoon.","new_memory":null,"steps":[{"action":"LAUNCH_APP","target":"YouTube","description":"YouTube kholna"},{"action":"SEARCH_YOUTUBE","target":"Arijit Singh songs","description":"Gaane search karna"},{"action":"CLICK_TEXT","target":"Arijit Singh","description":"Pehla video tap"}]}
            - "bharat ki rajdhani kya hai" -> {"reply":"Bharat ki rajdhani New Delhi hai, sir.","new_memory":null,"steps":[]}

            Output ONLY a JSON object with keys "reply", "new_memory", "steps".
        """.trimIndent()
    }

    private fun buildBody(systemText: String, prompt: String, useThinking: Boolean): JSONObject {
        return JSONObject().apply {
            put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemText))))
            put("contents", JSONArray().put(
                JSONObject()
                    .put("role", "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", prompt)))
            ))
            put("generationConfig", JSONObject().apply {
                put("responseMimeType", "application/json")
                put("maxOutputTokens", 1024)
                // Naye Gemini models temperature/top_p nahi lete; thinking kam rakhne se jawab jaldi aata hai.
                if (useThinking) put("thinkingConfig", JSONObject().put("thinkingLevel", "low"))
            })
        }
    }

    private fun extractText(raw: String): String {
        val parts = JSONObject(raw)
            .optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val part = parts.optJSONObject(i) ?: continue
            if (part.optBoolean("thought", false)) continue
            sb.append(part.optString("text", ""))
        }
        return sb.toString().trim()
    }

    private fun parseRoot(text: String): JSONObject? {
        val clean = text.replace("```json", "").replace("```", "").trim()
        try {
            if (clean.startsWith("[")) {
                return JSONObject().put("steps", JSONArray(clean))
            }
            return JSONObject(clean)
        } catch (e: Exception) {
            val start = clean.indexOf('{')
            val end = clean.lastIndexOf('}')
            if (start in 0 until end) {
                try {
                    return JSONObject(clean.substring(start, end + 1))
                } catch (e2: Exception) {
                    // neeche null
                }
            }
        }
        return null
    }

    private fun normalizeAction(raw: String): String {
        val a = raw.trim().uppercase().replace(Regex("[^A-Z0-9]+"), "_").trim('_')
        return when (a) {
            "OPEN_APP", "LAUNCH", "OPEN", "START_APP", "APP_LAUNCH", "OPEN_APPLICATION" -> "LAUNCH_APP"
            "YOUTUBE_SEARCH", "SEARCH_IN_YOUTUBE", "SEARCH_ON_YOUTUBE" -> "SEARCH_YOUTUBE"
            "TORCH", "FLASHLIGHT_ON", "TORCH_ENABLE", "TURN_ON_TORCH" -> "TORCH_ON"
            "FLASHLIGHT_OFF", "TORCH_DISABLE", "TURN_OFF_TORCH" -> "TORCH_OFF"
            "GOOGLE_SEARCH", "SEARCH", "WEB_SEARCH" -> "SEARCH_WEB"
            "TAP", "CLICK", "TAP_TEXT", "CLICK_ON" -> "CLICK_TEXT"
            "TYPE", "TYPE_TEXT", "ENTER_TEXT", "WRITE_TEXT" -> "INPUT_TEXT"
            "LOCK", "LOCK_PHONE" -> "LOCK_SCREEN"
            "CALL", "DIAL", "CALL_NUMBER" -> "DIAL_NUMBER"
            "REMEMBER", "SAVE_MEMORY", "SAVE_FACT" -> "REMEMBER_FACT"
            "OPEN_SETTINGS", "SETTINGS", "SETTING" -> "OPEN_SETTING"
            else -> a
        }
    }

    private fun parseGeminiJson(text: String, originalPrompt: String): GeminiExecutionResult {
        val obj = parseRoot(text)
            ?: return fallbackParse(originalPrompt).copy(note = "Gemini ka jawab JSON nahi tha: ${text.take(120)}")

        val reply = obj.optString("reply", "").ifBlank { "Ji sir, command execute kar raha hoon." }
        val newMemory = obj.optString("new_memory", "").takeIf { it.isNotBlank() && it != "null" }

        val stepsArray = obj.optJSONArray("steps")
        val stepsList = mutableListOf<JarvisExecutionStep>()
        if (stepsArray != null) {
            for (i in 0 until stepsArray.length()) {
                val item = stepsArray.opt(i)
                if (item is JSONObject) {
                    val rawAction = item.optString("action", "")
                        .ifBlank { item.optString("actionType", "") }
                        .ifBlank { item.optString("action_type", "") }
                        .ifBlank { item.optString("type", "") }
                    val target = item.optString("target", "")
                        .ifBlank { item.optString("app", "") }
                        .ifBlank { item.optString("app_name", "") }
                        .ifBlank { item.optString("query", "") }
                        .ifBlank { item.optString("value", "") }
                    val action = normalizeAction(rawAction)
                    if (action.isNotBlank()) {
                        val desc = item.optString("description", "").ifBlank { "Executing $action" }
                        stepsList.add(JarvisExecutionStep(actionType = action, target = target, description = desc))
                    }
                } else if (item is String) {
                    stepsList.add(inferStepFromString(item))
                }
            }
        }

        return GeminiExecutionResult(
            hinglishReply = reply,
            steps = stepsList,
            newMemoryToSave = newMemory,
            source = "GEMINI"
        )
    }

    private fun inferStepFromString(desc: String): JarvisExecutionStep {
        val lower = desc.lowercase()
        return when {
            lower.contains("torch") || lower.contains("flashlight") -> {
                if (lower.contains("off") || lower.contains("band"))
                    JarvisExecutionStep("TORCH_OFF", "", desc)
                else
                    JarvisExecutionStep("TORCH_ON", "", desc)
            }
            lower.contains("youtube") && lower.contains("search") -> {
                val query = desc.substringAfter("search").replace("'", "").replace("\"", "").trim()
                JarvisExecutionStep("SEARCH_YOUTUBE", query, desc)
            }
            lower.contains("youtube") -> JarvisExecutionStep("LAUNCH_APP", "YouTube", desc)
            lower.contains("volume") -> {
                if (lower.contains("down") || lower.contains("kam"))
                    JarvisExecutionStep("VOLUME_DOWN", "", desc)
                else
                    JarvisExecutionStep("VOLUME_UP", "", desc)
            }
            lower.contains("home") -> JarvisExecutionStep("HOME", "", desc)
            lower.contains("recent") -> JarvisExecutionStep("RECENTS", "", desc)
            lower.contains("lock") -> JarvisExecutionStep("LOCK_SCREEN", "", desc)
            lower.contains("tap") || lower.contains("click") -> JarvisExecutionStep("CLICK_TEXT", desc, desc)
            else -> JarvisExecutionStep("SEARCH_WEB", desc, desc)
        }
    }

    /**
     * Gemini ke bina chalne wala parse: pehle wahi tez local niyam, kuch match na ho to
     * ek saaf sa "samajh nahi aaya" jawab.
     */
    fun fallbackParse(prompt: String): GeminiExecutionResult {
        LocalCommandRouter.route(prompt, null, emptyList())?.let { return it }
        return GeminiExecutionResult(
            hinglishReply = "Sir, ye command main abhi samajh nahi paya. Thoda saaf bolkar dobara try karein.",
            steps = emptyList(),
            newMemoryToSave = null,
            source = "FALLBACK"
        )
    }
}
