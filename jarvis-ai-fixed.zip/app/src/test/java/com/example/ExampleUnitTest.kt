package com.example

import org.junit.Assert.*
import org.junit.Test

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testTorchCommandGeneratesTorchOnStep() {
    val result = com.example.util.GeminiAIService.fallbackParse("torch on karo")
    assertTrue(result.steps.isNotEmpty())
    assertEquals("TORCH_ON", result.steps[0].actionType)
  }

  @Test
  fun testComplexYouTubeCommandGeneratesMultiStepPlan() {
    val result = com.example.util.GeminiAIService.fallbackParse("YouTube kholo aur Arijit Singh ke gaane search karo")
    assertTrue(result.steps.size >= 2)
    assertEquals("LAUNCH_APP", result.steps[0].actionType)
    assertEquals("SEARCH_YOUTUBE", result.steps[1].actionType)
  }

  @Test
  fun testMemorySaveCommandExtractsFact() {
    val result = com.example.util.GeminiAIService.fallbackParse("yaad rakhna mera roll number 12 hai")
    assertNotNull(result.newMemoryToSave)
    assertTrue(result.newMemoryToSave!!.contains("roll number 12"))
  }

  private val sampleApps = listOf(
    com.example.model.InstalledAppInfo("Instagram", "com.instagram.android"),
    com.example.model.InstalledAppInfo("YouTube", "com.google.android.youtube"),
    com.example.model.InstalledAppInfo("WhatsApp", "com.whatsapp"),
    com.example.model.InstalledAppInfo("WhatsApp Business", "com.whatsapp.w4b"),
    com.example.model.InstalledAppInfo("Camera", "com.android.camera"),
    com.example.model.InstalledAppInfo("Calculator", "com.google.android.calculator")
  )

  @Test
  fun testCleanAppNameKeepsOnlyTheName() {
    assertEquals("instagram", com.example.util.AppMatcher.cleanAppName("instgram app open karna"))
  }

  @Test
  fun testFullSentenceWithTypoStillFindsInstagram() {
    val match = com.example.util.AppMatcher.findBest("instgram app open karna", sampleApps)
    assertNotNull(match)
    assertEquals("com.instagram.android", match!!.app.packageName)
  }

  @Test
  fun testSplitWhatsAppNameFindsWhatsApp() {
    val match = com.example.util.AppMatcher.findBest("whats app kholo", sampleApps)
    assertEquals("com.whatsapp", match?.app?.packageName)
  }

  @Test
  fun testUnknownAppIsNotMatched() {
    assertNull(com.example.util.AppMatcher.findBest("xyzzy", sampleApps))
  }

  @Test
  fun testLocalRouterOpensAppWithoutGemini() {
    val result = com.example.util.LocalCommandRouter.route("instagram kholo", null, sampleApps)
    assertNotNull(result)
    assertEquals("LAUNCH_APP", result!!.steps[0].actionType)
    assertEquals("com.instagram.android", result.steps[0].packageName)
  }

  @Test
  fun testLocalRouterReportsMissingAppHonestly() {
    val result = com.example.util.LocalCommandRouter.route("xyzzy kholo", null, sampleApps)
    assertNotNull(result)
    assertTrue(result!!.steps.isEmpty())
    assertTrue(result.hinglishReply.contains("nahi mila"))
  }

  @Test
  fun testLocalRouterHandlesTwoCommandsInOneSentence() {
    val result = com.example.util.LocalCommandRouter.route("torch on karo aur volume badhao", null, sampleApps)
    assertNotNull(result)
    assertEquals(listOf("TORCH_ON", "VOLUME_UP"), result!!.steps.map { it.actionType })
  }

  @Test
  fun testLocalRouterLeavesQuestionsToGemini() {
    assertNull(com.example.util.LocalCommandRouter.route("bharat ki rajdhani kya hai", null, sampleApps))
  }
}
