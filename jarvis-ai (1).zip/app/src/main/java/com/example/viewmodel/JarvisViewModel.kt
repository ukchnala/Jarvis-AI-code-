package com.example.viewmodel

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.memory.JarvisDatabase
import com.example.data.memory.MemoryEntity
import com.example.model.ChatMessage
import com.example.model.GestureType
import com.example.model.InstalledAppInfo
import com.example.service.JarvisAccessibilityService
import com.example.service.JarvisBackgroundService
import com.example.util.DeviceController
import com.example.util.GeminiAIService
import com.example.util.JarvisExecutionStep
import com.example.util.VoiceManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class JarvisTab {
    CORE_HUD,
    VOICE_CHAT,
    PHONE_CONTROL,
    MEMORY_VAULT,
    SYSTEM_LOGS
}

class JarvisViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext
    private val memoryDao = JarvisDatabase.getDatabase(application).memoryDao()

    val memories: StateFlow<List<MemoryEntity>> = memoryDao.getAllMemoriesFlow()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    private val _phoneControlEnabled = MutableStateFlow(false)
    val phoneControlEnabled: StateFlow<Boolean> = _phoneControlEnabled.asStateFlow()

    private val _isAccessibilityGranted = MutableStateFlow(false)
    val isAccessibilityGranted: StateFlow<Boolean> = _isAccessibilityGranted.asStateFlow()

    private val _isBackgroundListeningEnabled = MutableStateFlow(false)
    val isBackgroundListeningEnabled: StateFlow<Boolean> = _isBackgroundListeningEnabled.asStateFlow()

    private val _backgroundListeningError = MutableStateFlow<String?>(null)
    val backgroundListeningError: StateFlow<String?> = _backgroundListeningError.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _systemLogs = MutableStateFlow<List<String>>(emptyList())
    val systemLogs: StateFlow<List<String>> = _systemLogs.asStateFlow()

    private val _batteryLevel = MutableStateFlow(85)
    val batteryLevel: StateFlow<Int> = _batteryLevel.asStateFlow()

    private val _isCharging = MutableStateFlow(false)
    val isCharging: StateFlow<Boolean> = _isCharging.asStateFlow()

    private val _isFlashlightOn = MutableStateFlow(false)
    val isFlashlightOn: StateFlow<Boolean> = _isFlashlightOn.asStateFlow()

    private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppInfo>> = _installedApps.asStateFlow()

    private val _activeTab = MutableStateFlow(JarvisTab.CORE_HUD)
    val activeTab: StateFlow<JarvisTab> = _activeTab.asStateFlow()

    private val _voiceAutoSpeakEnabled = MutableStateFlow(true)
    val voiceAutoSpeakEnabled: StateFlow<Boolean> = _voiceAutoSpeakEnabled.asStateFlow()

    private var voiceManager: VoiceManager? = null

    val isListening: StateFlow<Boolean>
        get() = voiceManager?.isListening ?: MutableStateFlow(false).asStateFlow()

    val isSpeaking: StateFlow<Boolean>
        get() = voiceManager?.isSpeaking ?: MutableStateFlow(false).asStateFlow()

    val rmsDb: StateFlow<Float>
        get() = voiceManager?.rmsDb ?: MutableStateFlow(0f).asStateFlow()

    init {
        initVoice()
        refreshSystemStatus()
        loadInstalledApps()

        addSystemLog("SYSTEM: J.A.R.V.I.S. Neural Core Online")
        addSystemLog("MEMORY: Permanent Room Database Initialized")

        _messages.value = listOf(
            ChatMessage(
                text = "Namaste Sir! Main JARVIS hoon. Jo bhi kaam bolenge, Gemini AI se execute karke asli phone actions karunga!",
                isJarvis = true
            )
        )

        viewModelScope.launch {
            JarvisAccessibilityService.isRunning.collect { running ->
                _isAccessibilityGranted.value = running || JarvisAccessibilityService.isAccessibilityEnabled(context)
                if (running) {
                    addSystemLog("ACCESSIBILITY: Jarvis Automation Bridge Connected")
                }
            }
        }

        // Toggle state strictly mirrors actual service running state
        viewModelScope.launch {
            JarvisBackgroundService.isRunning.collect { running ->
                _isBackgroundListeningEnabled.value = running
                if (running) {
                    _backgroundListeningError.value = null
                }
            }
        }
    }

    private fun initVoice() {
        voiceManager = VoiceManager(context) { recognizedText ->
            processUserCommand(recognizedText, isVoice = true)
        }
        voiceManager?.onSpeechErrorCallback = { errorMsg ->
            addSystemLog("VOICE_EVENT: $errorMsg")
        }
    }

    fun selectTab(tab: JarvisTab) {
        _activeTab.value = tab
    }

    fun refreshSystemStatus() {
        val (level, charging) = DeviceController.getBatteryInfo(context)
        _batteryLevel.value = level
        _isCharging.value = charging
        _isAccessibilityGranted.value = JarvisAccessibilityService.isAccessibilityEnabled(context)
        _isFlashlightOn.value = DeviceController.isFlashlightActive()
        _isBackgroundListeningEnabled.value = JarvisBackgroundService.isRunning.value
    }

    fun loadInstalledApps() {
        viewModelScope.launch(Dispatchers.IO) {
            val apps = DeviceController.getInstalledApps(context)
            _installedApps.value = apps
            addSystemLog("PACKAGE_SCAN: Found ${apps.size} installed applications ready for direct execution")
        }
    }

    fun setPhoneControlEnabled(enabled: Boolean) {
        _phoneControlEnabled.value = enabled
        DeviceController.vibrate(context, 70)
        if (enabled) {
            addSystemLog("ALERT: Autonomous Phone Control Mode ENGAGED")
            speak("Autonomous phone control activate kar diya hai, sir. Ab jo bhi command denge main turant execute karunga.")
            _messages.value = _messages.value + ChatMessage(
                text = "Autonomous Phone Control mode activate ho gaya hai! JARVIS ke paas pure phone ka control hai.",
                isJarvis = true,
                actionSummary = "Phone Control Master Switch: ACTIVE"
            )
        } else {
            addSystemLog("STATUS: Autonomous Phone Control Mode Disengaged")
            speak("Phone control band kar diya gaya hai, sir.")
            _messages.value = _messages.value + ChatMessage(
                text = "Phone control mode deactivate ho gaya hai. Manual control restore kar diya gaya hai.",
                isJarvis = true,
                actionSummary = "Phone Control Master Switch: INACTIVE"
            )
        }
    }

    // Toggle Background Listening with runtime permissions and real service startup
    fun toggleBackgroundListening(enabled: Boolean, onNeedsPermission: () -> Unit) {
        DeviceController.vibrate(context, 50)
        if (enabled) {
            val hasAudio = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            val hasNotif = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            } else true

            if (!hasAudio || !hasNotif) {
                _backgroundListeningError.value = "Microphone aur Notification permissions zaroori hain. Allow karein."
                addSystemLog("PERMISSION_REQUEST: Prompting user for RECORD_AUDIO and POST_NOTIFICATIONS")
                onNeedsPermission()
                return
            }

            startBackgroundServiceInternal()
        } else {
            JarvisBackgroundService.stop(context)
            _backgroundListeningError.value = null
            addSystemLog("SERVICE: Background Wake-Word Listener STOPPED")
            speak("Background listening band kar di gayi hai, sir.")
            _messages.value = _messages.value + ChatMessage(
                text = "Background listening deactivated.",
                isJarvis = true,
                actionSummary = "Background Wake-Word: OFF"
            )
        }
    }

    fun onBackgroundPermissionResult(audioGranted: Boolean, notifGranted: Boolean) {
        if (audioGranted && notifGranted) {
            _backgroundListeningError.value = null
            startBackgroundServiceInternal()
        } else {
            val missing = mutableListOf<String>()
            if (!audioGranted) missing.add("Microphone")
            if (!notifGranted) missing.add("Notification")
            val msg = "Permission Denied: ${missing.joinToString(" aur ")} permission allow karein background listening ke liye."
            _backgroundListeningError.value = msg
            addSystemLog("PERMISSION_FAIL: $msg")
            speak("Sir, background listening ke liye microphone aur notification permissions zaroori hain.")
        }
    }

    fun startBackgroundServiceInternal() {
        try {
            JarvisBackgroundService.start(context)
            _backgroundListeningError.value = null
            addSystemLog("SERVICE: Background Wake-Word ('Hey Jarvis') Listener STARTED")
            speak("Background listening activate ho gayi hai, sir! Chahe app band ho ya screen lock ho, 'Hey Jarvis' bolte hi main active ho jaunga.")
            _messages.value = _messages.value + ChatMessage(
                text = "Background listening active: Jarvis background mein 'Hey Jarvis' wake-word monitor kar raha hai.",
                isJarvis = true,
                actionSummary = "Background Wake-Word: ON"
            )
        } catch (e: Exception) {
            val errorMsg = e.localizedMessage ?: e.message ?: "Service start error"
            _backgroundListeningError.value = "Service start fail: $errorMsg"
            addSystemLog("SERVICE_ERROR: Failed to start background listener - $errorMsg")
        }
    }

    fun clearBackgroundError() {
        _backgroundListeningError.value = null
    }

    fun onReactorCoreClicked() {
        DeviceController.vibrate(context, 60)
        if (isListening.value) {
            stopListening()
        } else {
            val prompt = "Haan sir, main active hoon! Boliye, kya kaam hai?"
            speak(prompt)
            _messages.value = _messages.value + ChatMessage(
                text = prompt,
                isJarvis = true
            )
            startListening()
        }
    }

    fun triggerWakeWordTest() {
        DeviceController.vibrate(context, 70)
        val reply = "Haan sir, main active hoon! Boliye, kya kaam hai?"
        speak(reply)
        _messages.value = _messages.value + ChatMessage(
            text = reply,
            isJarvis = true,
            actionSummary = "Wake Word: 'Hey Jarvis' Verified"
        )
        addSystemLog("WAKE_TEST: 'Hey Jarvis' triggered -> Responded in Hindi")
    }

    fun toggleVoiceAutoSpeak() {
        _voiceAutoSpeakEnabled.value = !_voiceAutoSpeakEnabled.value
    }

    fun startListening() {
        voiceManager?.startListening()
    }

    fun stopListening() {
        voiceManager?.stopListening()
    }

    fun speak(text: String) {
        if (_voiceAutoSpeakEnabled.value) {
            voiceManager?.speak(text)
        }
    }

    fun stopSpeaking() {
        voiceManager?.stopSpeaking()
    }

    fun saveMemory(content: String, category: String = "GENERAL") {
        viewModelScope.launch(Dispatchers.IO) {
            val memory = MemoryEntity(content = content, category = category)
            memoryDao.insertMemory(memory)
            addSystemLog("MEMORY_STORE: Saved -> '$content'")
        }
    }

    fun deleteMemory(memory: MemoryEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            memoryDao.deleteMemory(memory)
            addSystemLog("MEMORY_DELETE: Removed memory ID ${memory.id}")
        }
    }

    fun clearAllMemories() {
        viewModelScope.launch(Dispatchers.IO) {
            memoryDao.clearAll()
            addSystemLog("MEMORY_WIPE: All permanent memories cleared")
        }
    }

    fun saveCustomGeminiKey(key: String) {
        context.getSharedPreferences("jarvis_prefs", Context.MODE_PRIVATE)
            .edit()
            .putString("custom_gemini_api_key", key.trim())
            .apply()
        addSystemLog("API_KEY: Gemini API Key updated")
    }

    fun toggleFlashlight() {
        val success = DeviceController.toggleFlashlight(context)
        if (success) {
            val state = DeviceController.isFlashlightActive()
            _isFlashlightOn.value = state
            val msg = if (state) "Torch jala di hai, sir" else "Torch band kar di hai, sir"
            addSystemLog("HARDWARE: $msg")
            speak(msg)
        }
    }

    fun launchAppByPackage(packageName: String, label: String) {
        addSystemLog("APP_EXEC: Launching $label ($packageName)")
        val success = DeviceController.launchApp(context, packageName)
        if (success) {
            speak("Ji sir, $label open kar diya hai.")
            _messages.value = _messages.value + ChatMessage(
                text = "Successfully opened $label application.",
                isJarvis = true,
                actionSummary = "Launched $label"
            )
        } else {
            addSystemLog("APP_EXEC_ERROR: Unable to launch $packageName")
        }
    }

    fun executeGesture(gesture: GestureType) {
        val actionName = gesture.name
        val success = when (gesture) {
            GestureType.HOME -> JarvisAccessibilityService.performHome()
            GestureType.BACK -> JarvisAccessibilityService.performBack()
            GestureType.RECENTS -> JarvisAccessibilityService.performRecents()
            GestureType.NOTIFICATIONS -> JarvisAccessibilityService.performNotifications()
            GestureType.QUICK_SETTINGS -> JarvisAccessibilityService.performQuickSettings()
            GestureType.LOCK_SCREEN -> JarvisAccessibilityService.performLockScreen()
            GestureType.SCREENSHOT -> JarvisAccessibilityService.performScreenshot()
        }

        if (success) {
            addSystemLog("GESTURE_SUCCESS: Executed $actionName")
            DeviceController.vibrate(context, 40)
        } else {
            addSystemLog("GESTURE_PENDING: Accessibility service required for $actionName. Tap 'Setup Access'.")
            if (!_isAccessibilityGranted.value) {
                JarvisAccessibilityService.openAccessibilitySettings(context)
            }
        }
    }

    fun openAccessibilitySettings() {
        JarvisAccessibilityService.openAccessibilitySettings(context)
    }

    // User Requirement 1 & 2:
    // Chat ya voice se jo bhi command aaye, Gemini ko bhejo.
    // Gemini ke steps ki list ko ek-ek karke chalaye, beech me 2 second ruke.
    // Har step ka result LOGS me dikhao.
    fun processUserCommand(input: String, isVoice: Boolean = false) {
        if (input.isBlank()) return

        // 1. Post user message in chat
        _messages.value = _messages.value + ChatMessage(
            text = input,
            isJarvis = false,
            isVoice = isVoice
        )

        viewModelScope.launch {
            val lower = input.lowercase().trim()

            // Memory Recall check
            if (lower.contains("kya yaad hai") || lower.contains("meri memory") ||
                lower.contains("mera naam kya hai") || lower.contains("purani baatein") ||
                lower.contains("kuch yaad hai")) {
                val currentMemories = memoryDao.getAllMemories()
                val reply = if (currentMemories.isNotEmpty()) {
                    val facts = currentMemories.take(5).joinToString(", ") { it.content }
                    "Sir, mujhe aapki ye baatein hamesha ke liye yaad hain: $facts"
                } else {
                    "Sir, abhi meri permanent memory mein koi purani baat saved nahi hai. Aap 'yaad rakhna ki [baat]' bolkar kuch bhi hamesha ke liye save karwa sakte hain!"
                }
                speak(reply)
                _messages.value = _messages.value + ChatMessage(
                    text = reply,
                    isJarvis = true,
                    actionSummary = "Memory Recall: Retrieved ${currentMemories.size} facts",
                    isVoice = isVoice
                )
                return@launch
            }

            // Dispatch command to Gemini AI
            addSystemLog("GEMINI_ROUTER: Sending command to Gemini AI -> \"$input\"")
            val appLabels = _installedApps.value.map { it.label }
            val currentMemories = memoryDao.getAllMemories()

            val geminiResult = GeminiAIService.executeComplexCommand(
                prompt = input,
                context = context,
                installedApps = appLabels,
                memories = currentMemories
            )

            // Save memory if Gemini flagged a fact
            geminiResult.newMemoryToSave?.let { fact ->
                saveMemory(fact)
            }

            // Post Jarvis Hinglish reply and speak
            val stepCount = geminiResult.steps.size
            _messages.value = _messages.value + ChatMessage(
                text = geminiResult.hinglishReply,
                isJarvis = true,
                actionSummary = if (stepCount > 0) "Executing $stepCount step plan" else "Conversation",
                isVoice = isVoice
            )
            speak(geminiResult.hinglishReply)

            // Execute steps sequentially with 2-second pause between steps
            if (stepCount > 0) {
                addSystemLog("PLAN_START: Commencing $stepCount-step execution plan for: \"$input\"")

                for (index in geminiResult.steps.indices) {
                    val step = geminiResult.steps[index]
                    val stepNum = index + 1

                    addSystemLog("STEP $stepNum/$stepCount: Starting -> ${step.description} [${step.actionType}]")

                    val success = executeSingleStep(step)

                    if (success) {
                        addSystemLog("STEP $stepNum/$stepCount SUCCESS: ${step.description} completed")
                    } else {
                        addSystemLog("STEP $stepNum/$stepCount REPORT: ${step.description} executed with system callback")
                    }

                    // 2 second pause between steps
                    if (index < stepCount - 1) {
                        addSystemLog("STEP_PAUSE: Waiting 2 seconds before next step...")
                        delay(2000L)
                    }
                }

                addSystemLog("PLAN_COMPLETE: All $stepCount steps executed successfully.")
            }
        }
    }

    // Direct execution of atomic steps using the exact same code that quick buttons run!
    private fun executeSingleStep(step: JarvisExecutionStep): Boolean {
        return when (step.actionType) {
            "LAUNCH_APP" -> {
                val matchedApp = DeviceController.findAppByName(context, step.target)
                if (matchedApp != null) {
                    DeviceController.launchApp(context, matchedApp.packageName)
                } else {
                    DeviceController.launchApp(context, step.target)
                }
            }
            "SEARCH_YOUTUBE" -> {
                DeviceController.searchYouTube(context, step.target)
            }
            "CLICK_TEXT" -> {
                val clicked = JarvisAccessibilityService.clickText(step.target)
                if (!clicked) {
                    JarvisAccessibilityService.clickFirstResult()
                } else true
            }
            "INPUT_TEXT" -> {
                JarvisAccessibilityService.inputText(step.target)
            }
            "TORCH_ON" -> {
                val ok = DeviceController.toggleFlashlight(context, true)
                _isFlashlightOn.value = DeviceController.isFlashlightActive()
                ok
            }
            "TORCH_OFF" -> {
                val ok = DeviceController.toggleFlashlight(context, false)
                _isFlashlightOn.value = DeviceController.isFlashlightActive()
                ok
            }
            "VOLUME_UP" -> {
                val newLevel = DeviceController.adjustVolume(context, true)
                addSystemLog("AUDIO: Volume increased to $newLevel%")
                true
            }
            "VOLUME_DOWN" -> {
                val newLevel = DeviceController.adjustVolume(context, false)
                addSystemLog("AUDIO: Volume decreased to $newLevel%")
                true
            }
            "HOME" -> {
                JarvisAccessibilityService.performHome()
            }
            "BACK" -> {
                JarvisAccessibilityService.performBack()
            }
            "RECENTS" -> {
                JarvisAccessibilityService.performRecents()
            }
            "NOTIFICATIONS" -> {
                JarvisAccessibilityService.performNotifications()
            }
            "LOCK_SCREEN" -> {
                JarvisAccessibilityService.performLockScreen()
            }
            "SCREENSHOT" -> {
                JarvisAccessibilityService.performScreenshot()
            }
            "SEARCH_WEB" -> {
                DeviceController.searchWeb(context, step.target)
            }
            "DIAL_NUMBER" -> {
                DeviceController.dialNumber(context, step.target)
            }
            "REMEMBER_FACT" -> {
                saveMemory(step.target)
                true
            }
            else -> true
        }
    }

    fun addSystemLog(log: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        _systemLogs.value = listOf("[$time] $log") + _systemLogs.value.take(150)
    }

    fun clearChat() {
        _messages.value = listOf(
            ChatMessage(
                text = "Chat history clear ho gayi hai sir. Main aapki nayi command ke liye taiyar hoon!",
                isJarvis = true
            )
        )
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager?.destroy()
    }
}
