package com.example.util

import android.content.Context
import android.util.Log
import com.example.BuildConfig
import com.example.data.memory.MemoryEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class JarvisExecutionStep(
    val actionType: String,
    val target: String = "",
    val description: String
)

data class GeminiExecutionResult(
    val hinglishReply: String,
    val steps: List<JarvisExecutionStep>,
    val newMemoryToSave: String? = null
)

object GeminiAIService {
    private const val TAG = "GeminiAIService"

    private val httpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    fun getApiKey(context: Context): String {
        val prefKey = context.getSharedPreferences("jarvis_prefs", Context.MODE_PRIVATE)
            .getString("custom_gemini_api_key", "") ?: ""
        if (prefKey.isNotBlank()) return prefKey

        val buildKey = BuildConfig.GEMINI_API_KEY
        if (buildKey.isNotBlank() && buildKey != "MY_GEMINI_API_KEY") {
            return buildKey
        }
        return ""
    }

    fun isConfigured(context: Context): Boolean {
        return getApiKey(context).isNotBlank()
    }

    suspend fun executeComplexCommand(
        prompt: String,
        context: Context,
        installedApps: List<String>,
        memories: List<MemoryEntity>
    ): GeminiExecutionResult = withContext(Dispatchers.IO) {
        val apiKey = getApiKey(context)
        if (apiKey.isBlank()) {
            return@withContext fallbackParse(prompt)
        }

        try {
            val memoryContext = if (memories.isNotEmpty()) {
                "Permanent memories saved by user:\n" +
                        memories.take(30).joinToString("\n") { "- [ID ${it.id}] ${it.content}" }
            } else {
                "No prior memories saved yet."
            }

            val systemInstruction = """
                You are J.A.R.V.I.S., an advanced autonomous Android phone assistant.
                Your task is to take any user command (single or multi-step, simple or complex) and translate it into:
                1. A direct, polite HINGLISH speech reply (e.g. "Haan sir, YouTube open karke gaana play kar raha hoon.", "Ji sir, flashlight chalu kar di hai.").
                2. An ordered list of atomic execution steps for the Android phone to execute sequentially (with a pause between each step).
                3. Any permanent memory to save if the user tells you to remember something (e.g. "Mera naam...", "Yaad rakhna...").

                $memoryContext

                Installed Apps on Phone: ${installedApps.take(40).joinToString(", ")}.

                ALLOWED ACTION TYPES:
                - "LAUNCH_APP": Opens an app. "target" must be app name or package (e.g. "YouTube", "WhatsApp", "Camera", "Calculator").
                - "SEARCH_YOUTUBE": Searches inside YouTube for a video/song. "target" is search query.
                - "CLICK_TEXT": Taps on text/button on screen via Accessibility (e.g. video title, search button).
                - "INPUT_TEXT": Enters text in active input/search field.
                - "TORCH_ON": Turns flashlight ON. "target" is "".
                - "TORCH_OFF": Turns flashlight OFF. "target" is "".
                - "VOLUME_UP": Increases system media volume.
                - "VOLUME_DOWN": Decreases system media volume.
                - "HOME": Navigates to Home Screen.
                - "BACK": System back action.
                - "RECENTS": Opens recent apps screen.
                - "NOTIFICATIONS": Pulls down notification shade.
                - "LOCK_SCREEN": Locks phone screen.
                - "SCREENSHOT": Captures screen.
                - "SEARCH_WEB": Google web search. "target" is query.
                - "DIAL_NUMBER": Opens dialer with phone number. "target" is number.
                - "REMEMBER_FACT": Saves a fact into permanent memory vault. "target" is fact.

                EXAMPLES:
                - User: "torch on karo"
                  reply: "Ji sir, torch on kar di hai."
                  steps: [{"action": "TORCH_ON", "target": "", "description": "Flashlight ON karna"}]

                - User: "YouTube kholo aur Arijit Singh ke gaane search karo"
                  reply: "Haan sir, YouTube open karke Arijit Singh ke gaane search kar raha hoon."
                  steps: [
                    {"action": "LAUNCH_APP", "target": "YouTube", "description": "YouTube application open karna"},
                    {"action": "SEARCH_YOUTUBE", "target": "Arijit Singh songs", "description": "YouTube me 'Arijit Singh songs' search karna"},
                    {"action": "CLICK_TEXT", "target": "Arijit Singh", "description": "Pehla video tap karna"}
                  ]

                - User: "Mera Roll number 24 hai yaad rakhna"
                  reply: "Ji sir, maine yaad rakh liya hai ki aapka roll number 24 hai.",
                  new_memory: "User ka roll number 24 hai",
                  steps: [{"action": "REMEMBER_FACT", "target": "User ka roll number 24 hai", "description": "Permanent Memory Vault me save karna"}]

                Output STRICTLY JSON with keys: "reply", "new_memory" (string or null), and "steps" (array of objects with "action", "target", "description").
            """.trimIndent()

            val requestJson = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("role", "user")
                        put("parts", JSONArray().apply {
                            put(JSONObject().put("text", "$systemInstruction\n\nUser Command: $prompt"))
                        })
                    })
                })
                put("generationConfig", JSONObject().apply {
                    put("temperature", 0.2)
                    put("responseMimeType", "application/json")
                })
            }

            // Using verified gemini-3.8-flash endpoint
            val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=$apiKey"
            val body = requestJson.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url(endpoint)
                .post(body)
                .build()

            val response = httpClient.newCall(request).execute()
            val rawResponse = response.body?.string().orEmpty()

            if (!response.isSuccessful) {
                Log.e(TAG, "Gemini API error: ${response.code} $rawResponse")
                return@withContext fallbackParse(prompt)
            }

            val respObj = JSONObject(rawResponse)
            val candidates = respObj.optJSONArray("candidates")
            val firstCandidate = candidates?.optJSONObject(0)
            val content = firstCandidate?.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            val textOutput = parts?.optJSONObject(0)?.optString("text").orEmpty().trim()

            parseGeminiJson(textOutput, prompt)
        } catch (e: Exception) {
            Log.e(TAG, "Gemini call exception", e)
            fallbackParse(prompt)
        }
    }

    private fun parseGeminiJson(jsonStr: String, originalPrompt: String): GeminiExecutionResult {
        return try {
            val clean = jsonStr.replace("```json", "").replace("```", "").trim()
            val obj = JSONObject(clean)
            val reply = obj.optString("reply", "Ji sir, command execute kar di hai.")
            val newMemory = obj.optString("new_memory").takeIf { it.isNotBlank() && it != "null" }

            val stepsArray = obj.optJSONArray("steps")
            val stepsList = mutableListOf<JarvisExecutionStep>()

            if (stepsArray != null) {
                for (i in 0 until stepsArray.length()) {
                    val item = stepsArray.opt(i)
                    if (item is JSONObject) {
                        val action = item.optString("action", "")
                        val target = item.optString("target", "")
                        val desc = item.optString("description", "Executing $action")
                        if (action.isNotBlank()) {
                            stepsList.add(JarvisExecutionStep(actionType = action.uppercase(), target = target, description = desc))
                        }
                    } else if (item is String) {
                        // String step fallback
                        stepsList.add(inferStepFromString(item))
                    }
                }
            }

            // If Gemini returned conversational reply with 0 steps, check if original prompt had an obvious action
            if (stepsList.isEmpty()) {
                val fallbackSteps = fallbackParse(originalPrompt).steps
                if (fallbackSteps.isNotEmpty()) {
                    stepsList.addAll(fallbackSteps)
                }
            }

            GeminiExecutionResult(
                hinglishReply = reply,
                steps = stepsList,
                newMemoryToSave = newMemory
            )
        } catch (e: Exception) {
            fallbackParse(originalPrompt)
        }
    }

    private fun inferStepFromString(desc: String): JarvisExecutionStep {
        val lower = desc.lowercase()
        return when {
            lower.contains("torch") || lower.contains("flashlight") -> {
                if (lower.contains("off") || lower.contains("band"))
                    JarvisExecutionStep("TORCH_OFF", "", desc)
                else
                    JarvisExecutionStep("TORCH_ON", "", desc)
            }
            lower.contains("youtube") && lower.contains("search") -> {
                val query = desc.substringAfter("search").replace("'", "").replace("\"", "").trim()
                JarvisExecutionStep("SEARCH_YOUTUBE", query, desc)
            }
            lower.contains("youtube") -> JarvisExecutionStep("LAUNCH_APP", "YouTube", desc)
            lower.contains("volume") -> {
                if (lower.contains("down") || lower.contains("kam"))
                    JarvisExecutionStep("VOLUME_DOWN", "", desc)
                else
                    JarvisExecutionStep("VOLUME_UP", "", desc)
            }
            lower.contains("home") -> JarvisExecutionStep("HOME", "", desc)
            lower.contains("back") -> JarvisExecutionStep("BACK", "", desc)
            lower.contains("recent") -> JarvisExecutionStep("RECENTS", "", desc)
            lower.contains("lock") -> JarvisExecutionStep("LOCK_SCREEN", "", desc)
            lower.contains("tap") || lower.contains("click") -> JarvisExecutionStep("CLICK_TEXT", desc, desc)
            else -> JarvisExecutionStep("SEARCH_WEB", desc, desc)
        }
    }

    fun fallbackParse(prompt: String): GeminiExecutionResult {
        val query = prompt.trim().lowercase()
        val steps = mutableListOf<JarvisExecutionStep>()
        var reply = "Ji sir, maine aapki command receive kar li hai."
        var memoryToSave: String? = null

        // Flashlight
        if (query.contains("torch on") || query.contains("flashlight on") || query.contains("torch jalao") || query.contains("light on") || query.contains("batti jalao")) {
            reply = "Ji sir, torch on kar di hai."
            steps.add(JarvisExecutionStep("TORCH_ON", "", "Flashlight ON karna"))
        } else if (query.contains("torch off") || query.contains("flashlight off") || query.contains("torch band") || query.contains("light off") || query.contains("batti bujhao")) {
            reply = "Flashlight band kar di gayi hai, sir."
            steps.add(JarvisExecutionStep("TORCH_OFF", "", "Flashlight OFF karna"))
        }
        // YouTube complex task
        else if (query.contains("youtube") && (query.contains("search") || query.contains("gaana") || query.contains("song") || query.contains("play") || query.contains("chalao"))) {
            val term = query.replace("youtube kholo", "")
                .replace("youtube par", "")
                .replace("youtube", "")
                .replace("gaana chalao", "")
                .replace("search karo", "")
                .replace("chalao", "")
                .replace("play karo", "")
                .replace("aur", "")
                .trim()
            val effectiveTerm = if (term.isNotBlank()) term else "Arijit Singh songs"
            reply = "Haan sir, YouTube khol kar $effectiveTerm search kar raha hoon."
            steps.add(JarvisExecutionStep("LAUNCH_APP", "YouTube", "YouTube application open karna"))
            steps.add(JarvisExecutionStep("SEARCH_YOUTUBE", effectiveTerm, "YouTube me '$effectiveTerm' search karna"))
            steps.add(JarvisExecutionStep("CLICK_TEXT", effectiveTerm, "Pehla search result tap karna"))
        }
        // Launch App
        else if (query.startsWith("open ") || query.startsWith("kholo ") || query.endsWith("kholo") || query.contains("app kholo") || query.contains("launch ")) {
            val appName = query.replace("open", "").replace("kholo", "").replace("app", "").replace("launch", "").trim()
            reply = "Ji sir, $appName open kar diya hai."
            steps.add(JarvisExecutionStep("LAUNCH_APP", appName, "$appName app open karna"))
        }
        // Volume
        else if (query.contains("volume up") || query.contains("volume badhao") || query.contains("aawaz badhao") || query.contains("sound badhao")) {
            reply = "Volume badha diya hai, sir."
            steps.add(JarvisExecutionStep("VOLUME_UP", "", "Media volume badhana"))
        } else if (query.contains("volume down") || query.contains("volume kam karo") || query.contains("aawaz kam karo") || query.contains("sound kam")) {
            reply = "Volume kam kar diya hai, sir."
            steps.add(JarvisExecutionStep("VOLUME_DOWN", "", "Media volume kam karna"))
        }
        // Navigation Gestures
        else if (query.contains("home") || query.contains("home screen")) {
            reply = "Home screen par ja rahe hain, sir."
            steps.add(JarvisExecutionStep("HOME", "", "Home gesture execute karna"))
        } else if (query.contains("back") || query.contains("piche jao")) {
            reply = "Back kar diya hai, sir."
            steps.add(JarvisExecutionStep("BACK", "", "Back gesture execute karna"))
        } else if (query.contains("recent") || query.contains("multitasking")) {
            reply = "Recent running apps dikha raha hoon, sir."
            steps.add(JarvisExecutionStep("RECENTS", "", "Recent apps screen kholna"))
        } else if (query.contains("lock screen") || query.contains("phone lock") || query.contains("screen lock") || query.contains("lock karo")) {
            reply = "Phone lock kar diya gaya hai, sir."
            steps.add(JarvisExecutionStep("LOCK_SCREEN", "", "Phone lock karna"))
        }
        // Web Search
        else if (query.contains("search") || query.contains("google")) {
            val term = query.replace("search for", "").replace("search karo", "").replace("search", "").replace("google", "").trim()
            reply = "Ji sir, '$term' search kar raha hoon."
            steps.add(JarvisExecutionStep("SEARCH_WEB", term, "Google par '$term' search karna"))
        }
        // Memory save
        else if (query.contains("yaad rakhna") || query.contains("yaad rakho") || query.contains("save kar lo")) {
            val fact = query.replace("yaad rakhna ki", "").replace("yaad rakhna", "").replace("yaad rakho", "").replace("save kar lo", "").trim()
            val factToSave = if (fact.isNotBlank()) fact else prompt
            reply = "Ji sir, maine permanent memory mein save kar liya hai. Ye mujhe hamesha yaad rahega."
            memoryToSave = factToSave
            steps.add(JarvisExecutionStep("REMEMBER_FACT", factToSave, "Memory Vault me '$factToSave' save karna"))
        } else {
            // Conversational fallback
            reply = "Haan sir, main active hoon! Aap koi bhi task execute karne ko boliye jaise 'YouTube kholo', 'torch on karo', ya volume control."
        }

        return GeminiExecutionResult(
            hinglishReply = reply,
            steps = steps,
            newMemoryToSave = memoryToSave
        )
    }
}
