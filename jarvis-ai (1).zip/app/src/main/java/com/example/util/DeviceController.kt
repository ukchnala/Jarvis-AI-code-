package com.example.util

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import com.example.model.InstalledAppInfo

object DeviceController {

    private var isTorchOn = false

    fun toggleFlashlight(context: Context, forceState: Boolean? = null): Boolean {
        return try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
                ?: return false
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                val chars = cameraManager.getCameraCharacteristics(id)
                chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: cameraManager.cameraIdList.firstOrNull() ?: return false

            val newState = forceState ?: !isTorchOn
            cameraManager.setTorchMode(cameraId, newState)
            isTorchOn = newState
            vibrate(context, 50)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun isFlashlightActive(): Boolean = isTorchOn

    fun getBatteryInfo(context: Context): Pair<Int, Boolean> {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val level = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: 85
        val isCharging = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val status = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_STATUS) ?: -1
            status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        } else {
            false
        }
        return Pair(level.coerceIn(0, 100), isCharging)
    }

    fun adjustVolume(context: Context, increase: Boolean): Int {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return -1
        val direction = if (increase) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
        vibrate(context, 30)
        val current = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        return if (max > 0) (current * 100) / max else 50
    }

    fun getInstalledApps(context: Context): List<InstalledAppInfo> {
        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolved = pm.queryIntentActivities(mainIntent, 0)
        val appList = mutableListOf<InstalledAppInfo>()

        for (resolveInfo in resolved) {
            val packageName = resolveInfo.activityInfo.packageName
            val label = resolveInfo.loadLabel(pm).toString()
            val isSystem = (resolveInfo.activityInfo.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            if (packageName != context.packageName) {
                appList.add(InstalledAppInfo(label = label, packageName = packageName, isSystem = isSystem))
            }
        }
        return appList.distinctBy { it.packageName }.sortedBy { it.label.lowercase() }
    }

    fun launchApp(context: Context, packageName: String): Boolean {
        return try {
            val intent = context.packageManager.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                vibrate(context, 50)
                true
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }

    fun findAppByName(context: Context, query: String): InstalledAppInfo? {
        val cleanQuery = query.trim().lowercase()
        val apps = getInstalledApps(context)

        // Exact match
        apps.firstOrNull { it.label.lowercase() == cleanQuery }?.let { return it }

        // Common aliases
        val aliases = mapOf(
            "yt" to listOf("youtube"),
            "wa" to listOf("whatsapp"),
            "fb" to listOf("facebook"),
            "insta" to listOf("instagram"),
            "gpay" to listOf("google pay", "pay"),
            "calc" to listOf("calculator"),
            "cam" to listOf("camera"),
            "net" to listOf("browser", "chrome")
        )

        for ((alias, candidates) in aliases) {
            if (cleanQuery == alias || cleanQuery.contains(alias)) {
                for (cand in candidates) {
                    apps.firstOrNull { it.label.lowercase().contains(cand) || it.packageName.lowercase().contains(cand) }
                        ?.let { return it }
                }
            }
        }

        // Substring match on label
        apps.firstOrNull { it.label.lowercase().contains(cleanQuery) }?.let { return it }

        // Substring match on package
        return apps.firstOrNull { it.packageName.lowercase().contains(cleanQuery) }
    }

    fun openSystemSetting(context: Context, action: String): Boolean {
        return try {
            val intent = Intent(action).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            vibrate(context, 40)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun searchYouTube(context: Context, query: String): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_SEARCH).apply {
                setPackage("com.google.android.youtube")
                putExtra("query", query)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (intent.resolveActivity(context.packageManager) != null) {
                context.startActivity(intent)
                vibrate(context, 50)
                true
            } else {
                openUrl(context, "https://www.youtube.com/results?search_query=${Uri.encode(query)}")
            }
        } catch (e: Exception) {
            openUrl(context, "https://www.youtube.com/results?search_query=${Uri.encode(query)}")
        }
    }

    fun searchWeb(context: Context, query: String): Boolean {
        return try {
            val searchIntent = Intent(Intent.ACTION_WEB_SEARCH).apply {
                putExtra("query", query)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(searchIntent)
            vibrate(context, 40)
            true
        } catch (e: Exception) {
            openUrl(context, "https://www.google.com/search?q=${Uri.encode(query)}")
        }
    }

    fun openUrl(context: Context, url: String): Boolean {
        return try {
            val uri = if (url.startsWith("http://") || url.startsWith("https://")) {
                Uri.parse(url)
            } else {
                Uri.parse("https://$url")
            }
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            vibrate(context, 40)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun dialNumber(context: Context, number: String): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(number)}")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            vibrate(context, 40)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun vibrate(context: Context, durationMs: Long = 40) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val v = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v?.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    v?.vibrate(durationMs)
                }
            }
        } catch (e: Exception) {
            // Safe ignore
        }
    }
}
