package com.example

import org.junit.Assert.*
import org.junit.Test

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testTorchCommandGeneratesTorchOnStep() {
    val result = com.example.util.GeminiAIService.fallbackParse("torch on karo")
    assertTrue(result.steps.isNotEmpty())
    assertEquals("TORCH_ON", result.steps[0].actionType)
  }

  @Test
  fun testComplexYouTubeCommandGeneratesMultiStepPlan() {
    val result = com.example.util.GeminiAIService.fallbackParse("YouTube kholo aur Arijit Singh ke gaane search karo")
    assertTrue(result.steps.size >= 2)
    assertEquals("LAUNCH_APP", result.steps[0].actionType)
    assertEquals("SEARCH_YOUTUBE", result.steps[1].actionType)
  }

  @Test
  fun testMemorySaveCommandExtractsFact() {
    val result = com.example.util.GeminiAIService.fallbackParse("yaad rakhna mera roll number 12 hai")
    assertNotNull(result.newMemoryToSave)
    assertTrue(result.newMemoryToSave!!.contains("roll number 12"))
  }
}
